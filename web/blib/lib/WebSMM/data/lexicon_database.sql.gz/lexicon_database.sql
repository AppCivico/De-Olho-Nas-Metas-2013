--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: lexicon; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE lexicon (
    id integer NOT NULL,
    lang character varying(15) DEFAULT NULL::character varying,
    lex character varying(255) DEFAULT NULL::character varying,
    lex_key text,
    lex_value text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    origin_lang character varying DEFAULT 'pt-br'::character varying NOT NULL
);


ALTER TABLE lexicon OWNER TO postgres;

--
-- Name: lexicon_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE lexicon_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lexicon_id_seq OWNER TO postgres;

--
-- Name: lexicon_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE lexicon_id_seq OWNED BY lexicon.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY lexicon ALTER COLUMN id SET DEFAULT nextval('lexicon_id_seq'::regclass);


--
-- Data for Name: lexicon; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY lexicon (id, lang, lex, lex_key, lex_value, created_at, origin_lang) FROM stdin;
1	pt-br	*	Metas	Metas	2015-05-15 10:57:09.300759	pt-br
3	en	*	Metas	? Metas	2015-05-15 10:57:09.314569	pt-br
4	pt-br	*	Distritos	Distritos	2015-05-15 10:57:09.319731	pt-br
6	en	*	Distritos	? Distritos	2015-05-15 10:57:09.330275	pt-br
7	pt-br	*	Conselhos	Conselhos	2015-05-15 10:57:09.334698	pt-br
9	en	*	Conselhos	? Conselhos	2015-05-15 10:57:09.343295	pt-br
10	pt-br	*	Campanhas	Campanhas	2015-05-15 10:57:09.347033	pt-br
12	en	*	Campanhas	? Campanhas	2015-05-15 10:57:09.354643	pt-br
13	pt-br	*	Empresas	Empresas	2015-05-15 11:03:35.621321	pt-br
15	en	*	Empresas	? Empresas	2015-05-15 11:03:35.632008	pt-br
16	pt-br	*	Dados Abertos	Dados Abertos	2015-05-15 11:03:35.635688	pt-br
18	en	*	Dados Abertos	? Dados Abertos	2015-05-15 11:03:35.642518	pt-br
19	pt-br	*	Entrar	Entrar	2015-05-15 11:03:35.648179	pt-br
1000	pt-br	*	Contrasenã:	Contrasenã:	2015-08-24 11:41:20.93234	pt-br
21	en	*	Entrar	? Entrar	2015-05-15 11:03:35.655355	pt-br
22	pt-br	*	Sobre	Sobre	2015-05-15 11:03:35.65871	pt-br
1001	es	*	Contrasenã:	? Contrasenã:	2015-08-24 11:41:22.2052	pt-br
24	en	*	Sobre	? Sobre	2015-05-15 11:03:35.666325	pt-br
25	pt-br	*	Perguntas Frequentes	Perguntas Frequentes	2015-05-15 11:03:35.669765	pt-br
1002	en	*	Contrasenã:	? Contrasenã:	2015-08-24 11:41:22.294004	pt-br
27	en	*	Perguntas Frequentes	? Perguntas Frequentes	2015-05-15 11:03:35.676691	pt-br
28	pt-br	*	Contato	Contato	2015-05-15 11:03:35.679664	pt-br
1003	pt-br	*	? Senha:	? Senha:	2015-08-25 14:34:39.766629	pt-br
30	en	*	Contato	? Contato	2015-05-15 11:03:35.686483	pt-br
31	pt-br	*	Cadastro	Cadastro	2015-05-15 11:03:35.690672	pt-br
1004	es	*	? Senha:	? ? Senha:	2015-08-25 14:34:40.410931	pt-br
33	en	*	Cadastro	? Cadastro	2015-05-15 11:03:35.698397	pt-br
34	pt-br	*	Parceiros	Parceiros	2015-05-15 11:03:35.701907	pt-br
1005	en	*	? Senha:	? ? Senha:	2015-08-25 14:34:40.460889	pt-br
36	en	*	Parceiros	? Parceiros	2015-05-15 11:03:35.708864	pt-br
37	pt-br	*	Desenvolvimento	Desenvolvimento	2015-05-15 11:03:35.713825	pt-br
1006	pt-br	*	CONTRATO(S)	CONTRATO(S)	2015-08-25 18:06:18.644252	pt-br
39	en	*	Desenvolvimento	? Desenvolvimento	2015-05-15 11:03:35.720009	pt-br
40	pt-br	*	Meta Associada	Meta Associada	2015-05-15 11:05:21.709986	pt-br
1007	es	*	CONTRATO(S)	? CONTRATO(S)	2015-08-25 18:06:18.98217	pt-br
42	en	*	Meta Associada	? Meta Associada	2015-05-15 11:05:21.720687	pt-br
43	pt-br	*	Nenhum projeto encontrado	Nenhum projeto encontrado	2015-05-15 11:05:21.725255	pt-br
1008	en	*	CONTRATO(S)	? CONTRATO(S)	2015-08-25 18:06:19.036527	pt-br
45	en	*	Nenhum projeto encontrado	? Nenhum projeto encontrado	2015-05-15 11:05:21.734893	pt-br
46	pt-br	*	Projeto{{#plural}}s{{/plural}}	Projeto{{#plural}}s{{/plural}}	2015-05-15 11:09:47.790426	pt-br
1009	pt-br	*	Documentos	Documentos	2015-08-25 18:06:19.092668	pt-br
48	en	*	Projeto{{#plural}}s{{/plural}}	? Projeto{{#plural}}s{{/plural}}	2015-05-15 11:09:47.799274	pt-br
49	pt-br	*	Ajude a monitorar as Metas da cidade de São Paulo	Ajude a monitorar as Metas da cidade de São Paulo	2015-05-15 11:09:47.803287	pt-br
1010	es	*	Documentos	? Documentos	2015-08-25 18:06:19.114252	pt-br
51	en	*	Ajude a monitorar as Metas da cidade de São Paulo	? Ajude a monitorar as Metas da cidade de São Paulo	2015-05-15 11:09:47.811238	pt-br
52	pt-br	*	Use os filtros abaixo para ver os projetos no mapa	Use os filtros abaixo para ver os projetos no mapa	2015-05-15 11:09:47.814548	pt-br
1011	en	*	Documentos	? Documentos	2015-08-25 18:06:19.135819	pt-br
54	en	*	Use os filtros abaixo para ver os projetos no mapa	? Use os filtros abaixo para ver os projetos no mapa	2015-05-15 11:09:47.822241	pt-br
55	pt-br	*	CEP	CEP	2015-05-15 11:09:47.827327	pt-br
56	es	*	CEP	? CEP	2015-05-15 11:09:47.830633	pt-br
57	en	*	CEP	? CEP	2015-05-15 11:09:47.834099	pt-br
58	pt-br	*	por Distrito	por Distrito	2015-05-15 11:09:47.838867	pt-br
1012	pt-br	*	Documento não encontrado	Documento não encontrado	2015-08-25 18:06:19.159169	pt-br
60	en	*	por Distrito	? por Distrito	2015-05-15 11:09:47.845919	pt-br
61	pt-br	*	por Tema	por Tema	2015-05-15 11:09:47.852308	pt-br
1013	es	*	Documento não encontrado	? Documento não encontrado	2015-08-25 18:06:19.181258	pt-br
63	en	*	por Tema	? por Tema	2015-05-15 11:09:47.859016	pt-br
64	pt-br	*	Temas	Temas	2015-05-15 11:09:47.862232	pt-br
1014	en	*	Documento não encontrado	? Documento não encontrado	2015-08-25 18:06:19.203739	pt-br
66	en	*	Temas	? Temas	2015-05-15 11:09:47.869388	pt-br
67	pt-br	*	Pesquisar	Pesquisar	2015-05-15 11:10:12.465617	pt-br
1015	pt-br	*	Senha	Senha	2015-09-28 15:21:52.501682	pt-br
69	en	*	Pesquisar	? Pesquisar	2015-05-15 11:10:12.478455	pt-br
70	pt-br	*	Realização	Realização	2015-05-15 11:11:35.540722	pt-br
1016	es	*	Senha	? Senha	2015-09-28 15:21:52.966853	pt-br
72	en	*	Realização	? Realização	2015-05-15 11:11:35.550038	pt-br
73	pt-br	*	Apoio	Apoio	2015-05-15 11:11:35.554182	pt-br
1017	en	*	Senha	? Senha	2015-09-28 15:21:53.042029	pt-br
75	en	*	Apoio	? Apoio	2015-05-15 11:11:35.562183	pt-br
76	pt-br	*	Desenvolvido por	Desenvolvido por	2015-05-15 11:11:35.565476	pt-br
1018	pt-br	*	Confirmar senha	Confirmar senha	2015-10-07 11:36:28.138031	pt-br
78	en	*	Desenvolvido por	? Desenvolvido por	2015-05-15 11:11:35.577022	pt-br
79	pt-br	*	Projeto{{#plural}}s{{/plural}} Encontrado{{#plural}}s{{/plural}}	Projeto{{#plural}}s{{/plural}} Encontrado{{#plural}}s{{/plural}}	2015-05-15 11:13:25.272506	pt-br
1019	es	*	Confirmar senha	? Confirmar senha	2015-10-07 11:36:28.778388	pt-br
81	en	*	Projeto{{#plural}}s{{/plural}} Encontrado{{#plural}}s{{/plural}}	? Projeto{{#plural}}s{{/plural}} Encontrado{{#plural}}s{{/plural}}	2015-05-15 11:13:25.285623	pt-br
82	pt-br	*	Meta	Meta	2015-05-15 11:51:01.484482	pt-br
1020	en	*	Confirmar senha	? Confirmar senha	2015-10-07 11:36:28.888933	pt-br
84	en	*	Meta	? Meta	2015-05-15 11:51:01.494132	pt-br
85	pt-br	*	Regiões	Regiões	2015-05-15 11:51:01.497551	pt-br
1021	pt-br	*	Não está seguindo nenhum projeto	Não está seguindo nenhum projeto	2015-10-20 12:34:48.429762	pt-br
87	en	*	Regiões	? Regiões	2015-05-15 11:51:01.504255	pt-br
88	pt-br	*	Projetos	Projetos	2015-05-15 11:51:01.507646	pt-br
1022	es	*	Não está seguindo nenhum projeto	? Não está seguindo nenhum projeto	2015-10-20 12:34:48.608642	pt-br
90	en	*	Projetos	? Projetos	2015-05-15 11:51:01.514545	pt-br
91	pt-br	*	Distrito	Distrito	2015-05-15 11:51:01.520728	pt-br
1023	en	*	Não está seguindo nenhum projeto	? Não está seguindo nenhum projeto	2015-10-20 12:34:48.654938	pt-br
1024	pt-br	*	por Tipo de Organização	por Tipo de Organização	2015-11-03 16:09:05.090069	pt-br
1025	es	*	por Tipo de Organização	? por Tipo de Organização	2015-11-03 16:09:05.358681	pt-br
1026	en	*	por Tipo de Organização	? por Tipo de Organização	2015-11-03 16:09:05.385092	pt-br
1027	pt-br	*	Tipo de Organização	Tipo de Organização	2015-11-03 16:09:05.40861	pt-br
93	en	*	Distrito	? Distrito	2015-05-15 11:51:01.529534	pt-br
94	pt-br	*	Tweetar	Tweetar	2015-05-15 11:51:01.536563	pt-br
997	es	*	Senha:	Contrasenã:	2015-08-19 16:43:18.192088	pt-br
96	en	*	Tweetar	? Tweetar	2015-05-15 11:51:01.543444	pt-br
97	pt-br	*	INVESTIMENTO TOTAL PREVISTO	INVESTIMENTO TOTAL PREVISTO	2015-05-15 11:51:01.547747	pt-br
1028	es	*	Tipo de Organização	? Tipo de Organização	2015-11-03 16:09:05.455802	pt-br
99	en	*	INVESTIMENTO TOTAL PREVISTO	? INVESTIMENTO TOTAL PREVISTO	2015-05-15 11:51:01.555412	pt-br
100	pt-br	*	Linha do tempo segundo o cronograma	Linha do tempo segundo o cronograma	2015-05-15 11:51:01.558915	pt-br
1029	en	*	Tipo de Organização	? Tipo de Organização	2015-11-03 16:09:05.51634	pt-br
102	en	*	Linha do tempo segundo o cronograma	? Linha do tempo segundo o cronograma	2015-05-15 11:51:01.565426	pt-br
103	pt-br	*	Progresso de acordo com a prefeitura	Progresso de acordo com a prefeitura	2015-05-15 11:51:01.569226	pt-br
105	en	*	Progresso de acordo com a prefeitura	? Progresso de acordo com a prefeitura	2015-05-15 11:51:01.575755	pt-br
106	pt-br	*	Clique aqui	Clique aqui	2015-05-15 11:51:01.580001	pt-br
108	en	*	Clique aqui	? Clique aqui	2015-05-15 11:51:01.589774	pt-br
109	pt-br	*	para acompanhar o andamento do projeto no site Planeja Sampa	para acompanhar o andamento do projeto no site Planeja Sampa	2015-05-15 11:51:01.593604	pt-br
111	en	*	para acompanhar o andamento do projeto no site Planeja Sampa	? para acompanhar o andamento do projeto no site Planeja Sampa	2015-05-15 11:51:01.600546	pt-br
112	pt-br	*	de 6 etapas completas	de 6 etapas completas	2015-05-15 11:51:01.603895	pt-br
114	en	*	de 6 etapas completas	? de 6 etapas completas	2015-05-15 11:51:01.610825	pt-br
115	pt-br	*	Progresso segundo o Conselho Participativo	Progresso segundo o Conselho Participativo	2015-05-15 11:51:01.615328	pt-br
117	en	*	Progresso segundo o Conselho Participativo	? Progresso segundo o Conselho Participativo	2015-05-15 11:51:01.623249	pt-br
118	pt-br	*	Fonte das informações	Fonte das informações	2015-05-15 11:51:01.627424	pt-br
120	en	*	Fonte das informações	? Fonte das informações	2015-05-15 11:51:01.634732	pt-br
121	pt-br	*	Tribunal de Contas do Município de São Paulo	Tribunal de Contas do Município de São Paulo	2015-05-15 11:51:01.638387	pt-br
122	es	*	Tribunal de Contas do Município de São Paulo	? Tribunal de Contas do Município de São Paulo	2015-05-15 11:51:01.641628	pt-br
123	en	*	Tribunal de Contas do Município de São Paulo	? Tribunal de Contas do Município de São Paulo	2015-05-15 11:51:01.644849	pt-br
124	pt-br	*	Nome da Empresa	Nome da Empresa	2015-05-15 11:51:01.649138	pt-br
126	en	*	Nome da Empresa	? Nome da Empresa	2015-05-15 11:51:01.657397	pt-br
127	pt-br	*	Descrição da despesa	Descrição da despesa	2015-05-15 11:51:01.661073	pt-br
129	en	*	Descrição da despesa	? Descrição da despesa	2015-05-15 11:51:01.669333	pt-br
130	pt-br	*	Valor Empenhado	Valor Empenhado	2015-05-15 11:51:01.673011	pt-br
132	en	*	Valor Empenhado	? Valor Empenhado	2015-05-15 11:51:01.680083	pt-br
133	pt-br	*	Valor Liquidado	Valor Liquidado	2015-05-15 11:51:01.684067	pt-br
135	en	*	Valor Liquidado	? Valor Liquidado	2015-05-15 11:51:01.691831	pt-br
136	pt-br	*	Comentários	Comentários	2015-05-15 11:51:01.708267	pt-br
138	en	*	Comentários	? Comentários	2015-05-15 11:51:01.716054	pt-br
139	pt-br	*	Nome	Nome	2015-05-15 11:51:01.719448	pt-br
141	en	*	Nome	? Nome	2015-05-15 11:51:01.726643	pt-br
142	pt-br	*	Comentário	Comentário	2015-05-15 11:51:01.730347	pt-br
144	en	*	Comentário	? Comentário	2015-05-15 11:51:01.743898	pt-br
145	pt-br	*	Data	Data	2015-05-15 11:51:01.74958	pt-br
147	en	*	Data	? Data	2015-05-15 11:51:01.759179	pt-br
148	pt-br	*	Nenhum comentário encontrado	Nenhum comentário encontrado	2015-05-15 11:51:01.763386	pt-br
150	en	*	Nenhum comentário encontrado	? Nenhum comentário encontrado	2015-05-15 11:51:01.772491	pt-br
151	pt-br	*	Comentar	Comentar	2015-05-15 11:51:01.77639	pt-br
153	en	*	Comentar	? Comentar	2015-05-15 11:51:01.783683	pt-br
154	pt-br	*	Tema	Tema	2015-05-15 11:51:01.787589	pt-br
156	en	*	Tema	? Tema	2015-05-15 11:51:01.794886	pt-br
157	pt-br	*	Planeja Sampa	Planeja Sampa	2015-05-15 11:51:01.798689	pt-br
159	en	*	Planeja Sampa	? Planeja Sampa	2015-05-15 11:51:01.806748	pt-br
160	pt-br	*	Empresa	Empresa	2015-05-15 11:51:01.810574	pt-br
162	en	*	Empresa	? Empresa	2015-05-15 11:51:01.817955	pt-br
163	pt-br	*	Relacionada	Relacionada	2015-05-15 11:51:01.822294	pt-br
165	en	*	Relacionada	? Relacionada	2015-05-15 11:51:01.828923	pt-br
166	pt-br	*	Meta(s) Encontrada(s)	Meta(s) Encontrada(s)	2015-05-15 11:58:23.69454	pt-br
168	en	*	Meta(s) Encontrada(s)	? Meta(s) Encontrada(s)	2015-05-15 11:58:23.707669	pt-br
169	pt-br	*	Metas próximas a mim	Metas próximas a mim	2015-05-15 11:58:23.713298	pt-br
170	es	*	Metas próximas a mim	? Metas próximas a mim	2015-05-15 11:58:23.716685	pt-br
171	en	*	Metas próximas a mim	? Metas próximas a mim	2015-05-15 11:58:23.719734	pt-br
172	pt-br	*	Metas Encontradas	Metas Encontradas	2015-05-15 11:58:23.726306	pt-br
174	en	*	Metas Encontradas	? Metas Encontradas	2015-05-15 11:58:23.733446	pt-br
175	pt-br	*	Projeto(s)	Projeto(s)	2015-05-15 11:58:23.739168	pt-br
177	en	*	Projeto(s)	? Projeto(s)	2015-05-15 11:58:23.745965	pt-br
178	pt-br	*	Região	Região	2015-05-15 11:58:43.904862	pt-br
180	en	*	Região	? Região	2015-05-15 11:58:43.917287	pt-br
181	pt-br	*	Parar de Seguir	Parar de Seguir	2015-05-15 13:23:31.638001	pt-br
1030	pt-br	*	Membros da Organização	Membros da Organização	2015-11-09 15:15:47.997979	pt-br
183	en	*	Parar de Seguir	? Parar de Seguir	2015-05-15 13:23:31.645775	pt-br
184	pt-br	*	Siga o Projeto	Siga o Projeto	2015-05-15 13:23:31.649606	pt-br
1031	es	*	Membros da Organização	? Membros da Organização	2015-11-09 15:15:48.869923	pt-br
186	en	*	Siga o Projeto	? Siga o Projeto	2015-05-15 13:23:31.659404	pt-br
187	pt-br	*	Projeto	Projeto	2015-05-15 13:23:31.66783	pt-br
1032	en	*	Membros da Organização	? Membros da Organização	2015-11-09 15:15:48.986352	pt-br
189	en	*	Projeto	? Projeto	2015-05-15 13:23:31.67505	pt-br
190	pt-br	*	Acompanhar e receber notificações por email de cada atualização	Acompanhar e receber notificações por email de cada atualização	2015-05-15 13:23:31.678696	pt-br
1033	pt-br	*	Editar CONSELHO	Editar CONSELHO	2015-11-09 16:09:06.837922	pt-br
192	en	*	Acompanhar e receber notificações por email de cada atualização	? Acompanhar e receber notificações por email de cada atualização	2015-05-15 13:23:31.685524	pt-br
193	pt-br	*	Comentários dos conselheiros	Comentários dos conselheiros	2015-05-15 13:23:31.689683	pt-br
1034	es	*	Editar CONSELHO	? Editar CONSELHO	2015-11-09 16:09:06.870733	pt-br
195	en	*	Comentários dos conselheiros	? Comentários dos conselheiros	2015-05-15 13:23:31.697678	pt-br
196	pt-br	*	Conselheiro	Conselheiro	2015-05-15 13:23:31.700981	pt-br
1035	en	*	Editar CONSELHO	? Editar CONSELHO	2015-11-09 16:09:07.05161	pt-br
198	en	*	Conselheiro	? Conselheiro	2015-05-15 13:23:31.708428	pt-br
199	pt-br	*	Adicionar...	Adicionar...	2015-05-15 13:23:31.712726	pt-br
1036	pt-br	*	Organização	Organização	2015-11-11 11:02:47.118658	pt-br
201	en	*	Adicionar...	? Adicionar...	2015-05-15 13:23:31.719282	pt-br
202	pt-br	*	Iniciar	Iniciar	2015-05-15 13:23:31.723265	pt-br
1037	es	*	Organização	? Organização	2015-11-11 11:02:47.237121	pt-br
204	en	*	Iniciar	? Iniciar	2015-05-15 13:23:31.731239	pt-br
205	pt-br	*	Cancelar	Cancelar	2015-05-15 13:23:31.734522	pt-br
1038	en	*	Organização	? Organização	2015-11-11 11:02:47.283868	pt-br
207	en	*	Cancelar	? Cancelar	2015-05-15 13:23:31.741456	pt-br
208	pt-br	*	Fechar	Fechar	2015-05-15 13:23:31.745179	pt-br
210	en	*	Fechar	? Fechar	2015-05-15 13:23:31.752373	pt-br
211	pt-br	*	Processando...	Processando...	2015-05-15 13:23:31.757819	pt-br
213	en	*	Processando...	? Processando...	2015-05-15 13:23:31.768348	pt-br
214	pt-br	*	Erro	Erro	2015-05-15 13:23:31.772643	pt-br
216	en	*	Erro	? Erro	2015-05-15 13:23:31.781243	pt-br
217	pt-br	*	Apagar	Apagar	2015-05-15 13:23:31.785392	pt-br
219	en	*	Apagar	? Apagar	2015-05-15 13:23:31.792988	pt-br
220	pt-br	*	Perfil e ferramentas	Perfil e ferramentas	2015-05-15 13:24:02.947313	pt-br
222	en	*	Perfil e ferramentas	? Perfil e ferramentas	2015-05-15 13:24:02.956231	pt-br
223	pt-br	*	Meu Perfil	Meu Perfil	2015-05-15 13:24:02.960021	pt-br
225	en	*	Meu Perfil	? Meu Perfil	2015-05-15 13:24:02.969275	pt-br
226	pt-br	*	Sair	Sair	2015-05-15 13:24:02.976986	pt-br
228	en	*	Sair	? Sair	2015-05-15 13:24:02.983624	pt-br
229	pt-br	*	Opinião dos conselheiros sobre o progresso do projeto	Opinião dos conselheiros sobre o progresso do projeto	2015-05-15 13:24:41.077611	pt-br
231	en	*	Opinião dos conselheiros sobre o progresso do projeto	? Opinião dos conselheiros sobre o progresso do projeto	2015-05-15 13:24:41.087151	pt-br
232	pt-br	*	Nenhuma imagem cadastrada	Nenhuma imagem cadastrada	2015-05-15 13:24:41.091291	pt-br
234	en	*	Nenhuma imagem cadastrada	? Nenhuma imagem cadastrada	2015-05-15 13:24:41.098779	pt-br
235	pt-br	*	Dados abertos	Dados abertos	2015-05-19 10:22:37.077645	pt-br
237	en	*	Dados abertos	? Dados abertos	2015-05-19 10:22:37.088426	pt-br
238	pt-br	*	O que são dados abertos	O que são dados abertos	2015-05-19 10:22:37.09332	pt-br
240	en	*	O que são dados abertos	? O que são dados abertos	2015-05-19 10:22:37.105243	pt-br
241	pt-br	*	Segundo a definição da Open Knowledge Foundation, em suma	Segundo a definição da Open Knowledge Foundation, em suma	2015-05-19 10:22:37.108878	pt-br
242	es	*	Segundo a definição da Open Knowledge Foundation, em suma	? Segundo a definição da Open Knowledge Foundation, em suma	2015-05-19 10:22:37.112213	pt-br
243	en	*	Segundo a definição da Open Knowledge Foundation, em suma	? Segundo a definição da Open Knowledge Foundation, em suma	2015-05-19 10:22:37.115399	pt-br
244	pt-br	*	dados são abertos quando qualquer pessoa pode livremente usá-los, reutilizá-los e redistribuí-los, estando sujeito a, no máximo, a exigência de creditar a sua autoria e compartilhar pela mesma licença	dados são abertos quando qualquer pessoa pode livremente usá-los, reutilizá-los e redistribuí-los, estando sujeito a, no máximo, a exigência de creditar a sua autoria e compartilhar pela mesma licença	2015-05-19 10:22:37.118978	pt-br
245	es	*	dados são abertos quando qualquer pessoa pode livremente usá-los, reutilizá-los e redistribuí-los, estando sujeito a, no máximo, a exigência de creditar a sua autoria e compartilhar pela mesma licença	? dados são abertos quando qualquer pessoa pode livremente usá-los, reutilizá-los e redistribuí-los, estando sujeito a, no máximo, a exigência de creditar a sua autoria e compartilhar pela mesma licença	2015-05-19 10:22:37.122852	pt-br
411	en	*	Endereço	? Endereço	2015-05-19 10:22:37.775544	pt-br
246	en	*	dados são abertos quando qualquer pessoa pode livremente usá-los, reutilizá-los e redistribuí-los, estando sujeito a, no máximo, a exigência de creditar a sua autoria e compartilhar pela mesma licença	? dados são abertos quando qualquer pessoa pode livremente usá-los, reutilizá-los e redistribuí-los, estando sujeito a, no máximo, a exigência de creditar a sua autoria e compartilhar pela mesma licença	2015-05-19 10:22:37.127198	pt-br
247	pt-br	*	Você pode saber mais sobre o assunto acessando	Você pode saber mais sobre o assunto acessando	2015-05-19 10:22:37.132056	pt-br
249	en	*	Você pode saber mais sobre o assunto acessando	? Você pode saber mais sobre o assunto acessando	2015-05-19 10:22:37.139914	pt-br
250	pt-br	*	o Portal de dados abertos do Brasil	o Portal de dados abertos do Brasil	2015-05-19 10:22:37.14325	pt-br
252	en	*	o Portal de dados abertos do Brasil	? o Portal de dados abertos do Brasil	2015-05-19 10:22:37.1515	pt-br
253	pt-br	*	API para desenvolvedores	API para desenvolvedores	2015-05-19 10:22:37.155373	pt-br
255	en	*	API para desenvolvedores	? API para desenvolvedores	2015-05-19 10:22:37.161955	pt-br
256	pt-br	*	Você também pode consultar os dados que estão armazenados no DONM via API	Você também pode consultar os dados que estão armazenados no DONM via API	2015-05-19 10:22:37.165217	pt-br
258	en	*	Você também pode consultar os dados que estão armazenados no DONM via API	? Você também pode consultar os dados que estão armazenados no DONM via API	2015-05-19 10:22:37.171403	pt-br
259	pt-br	*	Para saber mais, navegue até a seção	Para saber mais, navegue até a seção	2015-05-19 10:22:37.174635	pt-br
260	es	*	Para saber mais, navegue até a seção	? Para saber mais, navegue até a seção	2015-05-19 10:22:37.177877	pt-br
261	en	*	Para saber mais, navegue até a seção	? Para saber mais, navegue até a seção	2015-05-19 10:22:37.181546	pt-br
262	pt-br	*	Baixar arquivos	Baixar arquivos	2015-05-19 10:22:37.186177	pt-br
264	en	*	Baixar arquivos	? Baixar arquivos	2015-05-19 10:22:37.194033	pt-br
265	pt-br	*	Tabelas	Tabelas	2015-05-19 10:22:37.198684	pt-br
267	en	*	Tabelas	? Tabelas	2015-05-19 10:22:37.208518	pt-br
268	pt-br	*	Objetivos	Objetivos	2015-05-19 10:22:37.214557	pt-br
270	en	*	Objetivos	? Objetivos	2015-05-19 10:22:37.224597	pt-br
271	pt-br	*	Orçamentos	Orçamentos	2015-05-19 10:22:37.22877	pt-br
273	en	*	Orçamentos	? Orçamentos	2015-05-19 10:22:37.236136	pt-br
274	pt-br	*	Subprefeituras	Subprefeituras	2015-05-19 10:22:37.239711	pt-br
276	en	*	Subprefeituras	? Subprefeituras	2015-05-19 10:22:37.24766	pt-br
277	pt-br	*	Formato	Formato	2015-05-19 10:22:37.251418	pt-br
279	en	*	Formato	? Formato	2015-05-19 10:22:37.257955	pt-br
280	pt-br	*	Links	Links	2015-05-19 10:22:37.261237	pt-br
282	en	*	Links	? Links	2015-05-19 10:22:37.268405	pt-br
283	pt-br	*	Arquivo das tabelas	Arquivo das tabelas	2015-05-19 10:22:37.27164	pt-br
285	en	*	Arquivo das tabelas	? Arquivo das tabelas	2015-05-19 10:22:37.27827	pt-br
286	pt-br	*	Informações contidas nos arquivos	Informações contidas nos arquivos	2015-05-19 10:22:37.282265	pt-br
288	en	*	Informações contidas nos arquivos	? Informações contidas nos arquivos	2015-05-19 10:22:37.289682	pt-br
289	pt-br	*	Campos dos arquivos	Campos dos arquivos	2015-05-19 10:22:37.293117	pt-br
291	en	*	Campos dos arquivos	? Campos dos arquivos	2015-05-19 10:22:37.300984	pt-br
292	pt-br	*	ID da meta	ID da meta	2015-05-19 10:22:37.304813	pt-br
294	en	*	ID da meta	? ID da meta	2015-05-19 10:22:37.311446	pt-br
295	pt-br	*	Descrição	Descrição	2015-05-19 10:22:37.314866	pt-br
297	en	*	Descrição	? Descrição	2015-05-19 10:22:37.321602	pt-br
298	pt-br	*	Orçamento esperado	Orçamento esperado	2015-05-19 10:22:37.324932	pt-br
300	en	*	Orçamento esperado	? Orçamento esperado	2015-05-19 10:22:37.331636	pt-br
301	pt-br	*	Número da meta	Número da meta	2015-05-19 10:22:37.335749	pt-br
303	en	*	Número da meta	? Número da meta	2015-05-19 10:22:37.343534	pt-br
304	pt-br	*	Data de atualização	Data de atualização	2015-05-19 10:22:37.347426	pt-br
306	en	*	Data de atualização	? Data de atualização	2015-05-19 10:22:37.354369	pt-br
307	pt-br	*	Data esperada para início	Data esperada para início	2015-05-19 10:22:37.358009	pt-br
309	en	*	Data esperada para início	? Data esperada para início	2015-05-19 10:22:37.365397	pt-br
310	pt-br	*	Data esperada para termino	Data esperada para termino	2015-05-19 10:22:37.370842	pt-br
312	en	*	Data esperada para termino	? Data esperada para termino	2015-05-19 10:22:37.381579	pt-br
313	pt-br	*	Será entregue	Será entregue	2015-05-19 10:22:37.38564	pt-br
314	es	*	Será entregue	? Será entregue	2015-05-19 10:22:37.389549	pt-br
315	en	*	Será entregue	? Será entregue	2015-05-19 10:22:37.393352	pt-br
316	pt-br	*	Transversalidade	Transversalidade	2015-05-19 10:22:37.397026	pt-br
318	en	*	Transversalidade	? Transversalidade	2015-05-19 10:22:37.407312	pt-br
319	pt-br	*	Progresso Qualitativo 1	Progresso Qualitativo 1	2015-05-19 10:22:37.411923	pt-br
321	en	*	Progresso Qualitativo 1	? Progresso Qualitativo 1	2015-05-19 10:22:37.418846	pt-br
322	pt-br	*	Progresso Qualitativo 2	Progresso Qualitativo 2	2015-05-19 10:22:37.422432	pt-br
324	en	*	Progresso Qualitativo 2	? Progresso Qualitativo 2	2015-05-19 10:22:37.429196	pt-br
325	pt-br	*	Progresso Qualitativo 3	Progresso Qualitativo 3	2015-05-19 10:22:37.433082	pt-br
327	en	*	Progresso Qualitativo 3	? Progresso Qualitativo 3	2015-05-19 10:22:37.440418	pt-br
328	pt-br	*	Progresso Qualitativo 4	Progresso Qualitativo 4	2015-05-19 10:22:37.443853	pt-br
330	en	*	Progresso Qualitativo 4	? Progresso Qualitativo 4	2015-05-19 10:22:37.455682	pt-br
331	pt-br	*	Progresso Qualitativo 5	Progresso Qualitativo 5	2015-05-19 10:22:37.459608	pt-br
333	en	*	Progresso Qualitativo 5	? Progresso Qualitativo 5	2015-05-19 10:22:37.468037	pt-br
334	pt-br	*	Progresso Qualitativo 6	Progresso Qualitativo 6	2015-05-19 10:22:37.471817	pt-br
336	en	*	Progresso Qualitativo 6	? Progresso Qualitativo 6	2015-05-19 10:22:37.478714	pt-br
337	pt-br	*	Objetivo	Objetivo	2015-05-19 10:22:37.482647	pt-br
339	en	*	Objetivo	? Objetivo	2015-05-19 10:22:37.489798	pt-br
340	pt-br	*	ID do objetivo	ID do objetivo	2015-05-19 10:22:37.492907	pt-br
342	en	*	ID do objetivo	? ID do objetivo	2015-05-19 10:22:37.499217	pt-br
343	pt-br	*	ID do projeto	ID do projeto	2015-05-19 10:22:37.502274	pt-br
345	en	*	ID do projeto	? ID do projeto	2015-05-19 10:22:37.508792	pt-br
346	pt-br	*	latitude	latitude	2015-05-19 10:22:37.51229	pt-br
348	en	*	latitude	? latitude	2015-05-19 10:22:37.520641	pt-br
349	pt-br	*	longitude	longitude	2015-05-19 10:22:37.525778	pt-br
351	en	*	longitude	? longitude	2015-05-19 10:22:37.534311	pt-br
352	pt-br	*	Número do projeto	Número do projeto	2015-05-19 10:22:37.538894	pt-br
354	en	*	Número do projeto	? Número do projeto	2015-05-19 10:22:37.548192	pt-br
355	pt-br	*	Porcentagem	Porcentagem	2015-05-19 10:22:37.553524	pt-br
357	en	*	Porcentagem	? Porcentagem	2015-05-19 10:22:37.561028	pt-br
358	pt-br	*	ID da empresa	ID da empresa	2015-05-19 10:22:37.564871	pt-br
360	en	*	ID da empresa	? ID da empresa	2015-05-19 10:22:37.57243	pt-br
361	pt-br	*	Url do nome	Url do nome	2015-05-19 10:22:37.575877	pt-br
363	en	*	Url do nome	? Url do nome	2015-05-19 10:22:37.582829	pt-br
364	pt-br	*	Orçamento	Orçamento	2015-05-19 10:22:37.587348	pt-br
366	en	*	Orçamento	? Orçamento	2015-05-19 10:22:37.593824	pt-br
367	pt-br	*	ID do orçamento	ID do orçamento	2015-05-19 10:22:37.597132	pt-br
369	en	*	ID do orçamento	? ID do orçamento	2015-05-19 10:22:37.603269	pt-br
370	pt-br	*	Nome da empresa	Nome da empresa	2015-05-19 10:22:37.606382	pt-br
372	en	*	Nome da empresa	? Nome da empresa	2015-05-19 10:22:37.612678	pt-br
373	pt-br	*	CNPJ	CNPJ	2015-05-19 10:22:37.617597	pt-br
374	es	*	CNPJ	? CNPJ	2015-05-19 10:22:37.62136	pt-br
375	en	*	CNPJ	? CNPJ	2015-05-19 10:22:37.625158	pt-br
376	pt-br	*	Valor Dedicado	Valor Dedicado	2015-05-19 10:22:37.62918	pt-br
378	en	*	Valor Dedicado	? Valor Dedicado	2015-05-19 10:22:37.637223	pt-br
379	pt-br	*	Valor liquidado	Valor liquidado	2015-05-19 10:22:37.640878	pt-br
381	en	*	Valor liquidado	? Valor liquidado	2015-05-19 10:22:37.649236	pt-br
382	pt-br	*	Observação	Observação	2015-05-19 10:22:37.653671	pt-br
384	en	*	Observação	? Observação	2015-05-19 10:22:37.660901	pt-br
385	pt-br	*	Código de contrato	Código de contrato	2015-05-19 10:22:37.665613	pt-br
387	en	*	Código de contrato	? Código de contrato	2015-05-19 10:22:37.673481	pt-br
388	pt-br	*	Código da organização	Código da organização	2015-05-19 10:22:37.676844	pt-br
390	en	*	Código da organização	? Código da organização	2015-05-19 10:22:37.68843	pt-br
391	pt-br	*	Nome da organização	Nome da organização	2015-05-19 10:22:37.695077	pt-br
393	en	*	Nome da organização	? Nome da organização	2015-05-19 10:22:37.704036	pt-br
394	pt-br	*	Id da empresa	Id da empresa	2015-05-19 10:22:37.707979	pt-br
396	en	*	Id da empresa	? Id da empresa	2015-05-19 10:22:37.714888	pt-br
397	pt-br	*	Conselho	Conselho	2015-05-19 10:22:37.721686	pt-br
399	en	*	Conselho	? Conselho	2015-05-19 10:22:37.732974	pt-br
400	pt-br	*	ID do conselho	ID do conselho	2015-05-19 10:22:37.737433	pt-br
402	en	*	ID do conselho	? ID do conselho	2015-05-19 10:22:37.74563	pt-br
403	pt-br	*	Nome do conselho	Nome do conselho	2015-05-19 10:22:37.749105	pt-br
405	en	*	Nome do conselho	? Nome do conselho	2015-05-19 10:22:37.75533	pt-br
406	pt-br	*	Telefone	Telefone	2015-05-19 10:22:37.758509	pt-br
408	en	*	Telefone	? Telefone	2015-05-19 10:22:37.764616	pt-br
409	pt-br	*	Endereço	Endereço	2015-05-19 10:22:37.768741	pt-br
412	pt-br	*	Complemento	Complemento	2015-05-19 10:22:37.778679	pt-br
414	en	*	Complemento	? Complemento	2015-05-19 10:22:37.784974	pt-br
415	pt-br	*	Código postal	Código postal	2015-05-19 10:22:37.788135	pt-br
417	en	*	Código postal	? Código postal	2015-05-19 10:22:37.794024	pt-br
418	pt-br	*	Site	Site	2015-05-19 10:22:37.797189	pt-br
420	en	*	Site	? Site	2015-05-19 10:22:37.807873	pt-br
421	pt-br	*	ID do distrito	ID do distrito	2015-05-19 10:22:37.811379	pt-br
423	en	*	ID do distrito	? ID do distrito	2015-05-19 10:22:37.819652	pt-br
424	pt-br	*	Nome do distrito	Nome do distrito	2015-05-19 10:22:37.829431	pt-br
426	en	*	Nome do distrito	? Nome do distrito	2015-05-19 10:22:37.84124	pt-br
427	pt-br	*	Latitude	Latitude	2015-05-19 10:22:37.845107	pt-br
429	en	*	Latitude	? Latitude	2015-05-19 10:22:37.853102	pt-br
430	pt-br	*	Longitude	Longitude	2015-05-19 10:22:37.857003	pt-br
432	en	*	Longitude	? Longitude	2015-05-19 10:22:37.864256	pt-br
433	pt-br	*	Coordenadas Geométricas	Coordenadas Geométricas	2015-05-19 10:22:37.867654	pt-br
435	en	*	Coordenadas Geométricas	? Coordenadas Geométricas	2015-05-19 10:22:37.873685	pt-br
436	pt-br	*	Subprefeitura	Subprefeitura	2015-05-19 10:22:37.876916	pt-br
438	en	*	Subprefeitura	? Subprefeitura	2015-05-19 10:22:37.884443	pt-br
439	pt-br	*	ID da subprefeitura	ID da subprefeitura	2015-05-19 10:22:37.888937	pt-br
441	en	*	ID da subprefeitura	? ID da subprefeitura	2015-05-19 10:22:37.895729	pt-br
442	pt-br	*	Nome da subprefeitura	Nome da subprefeitura	2015-05-19 10:22:37.899326	pt-br
444	en	*	Nome da subprefeitura	? Nome da subprefeitura	2015-05-19 10:22:37.90545	pt-br
445	pt-br	*	E-mail	E-mail	2015-05-19 10:22:37.908962	pt-br
447	en	*	E-mail	? E-mail	2015-05-19 10:22:37.915631	pt-br
448	pt-br	*	Subprefeito	Subprefeito	2015-05-19 10:22:37.920219	pt-br
450	en	*	Subprefeito	? Subprefeito	2015-05-19 10:22:37.927716	pt-br
451	pt-br	*	O DONM fornece uma REST API para a consulta dos dados	O DONM fornece uma REST API para a consulta dos dados	2015-05-19 10:22:37.931251	pt-br
453	en	*	O DONM fornece uma REST API para a consulta dos dados	? O DONM fornece uma REST API para a consulta dos dados	2015-05-19 10:22:37.937729	pt-br
454	pt-br	*	Os <b>endpoints</b> podem entregar o contéudo serializado em	Os <b>endpoints</b> podem entregar o contéudo serializado em	2015-05-19 10:22:37.940789	pt-br
456	en	*	Os <b>endpoints</b> podem entregar o contéudo serializado em	? Os <b>endpoints</b> podem entregar o contéudo serializado em	2015-05-19 10:22:37.94768	pt-br
457	pt-br	*	O	O	2015-05-19 10:22:37.951497	pt-br
459	en	*	O	? O	2015-05-19 10:22:37.958867	pt-br
460	pt-br	*	é definido automaticamente pelo header	é definido automaticamente pelo header	2015-05-19 10:22:37.962257	pt-br
462	en	*	é definido automaticamente pelo header	? é definido automaticamente pelo header	2015-05-19 10:22:37.969092	pt-br
463	pt-br	*	Por padrão, a resposta é no formato	Por padrão, a resposta é no formato	2015-05-19 10:22:37.972495	pt-br
464	es	*	Por padrão, a resposta é no formato	? Por padrão, a resposta é no formato	2015-05-19 10:22:37.975569	pt-br
465	en	*	Por padrão, a resposta é no formato	? Por padrão, a resposta é no formato	2015-05-19 10:22:37.978498	pt-br
466	pt-br	*	Para pedir manualmente, utilize	Para pedir manualmente, utilize	2015-05-19 10:22:37.98179	pt-br
467	es	*	Para pedir manualmente, utilize	? Para pedir manualmente, utilize	2015-05-19 10:22:37.985671	pt-br
468	en	*	Para pedir manualmente, utilize	? Para pedir manualmente, utilize	2015-05-19 10:22:37.989353	pt-br
469	pt-br	*	para JSON	para JSON	2015-05-19 10:22:37.993572	pt-br
470	es	*	para JSON	? para JSON	2015-05-19 10:22:37.996869	pt-br
471	en	*	para JSON	? para JSON	2015-05-19 10:22:38.000345	pt-br
472	pt-br	*	Parâmetros aceitos	Parâmetros aceitos	2015-05-19 10:22:38.003699	pt-br
474	en	*	Parâmetros aceitos	? Parâmetros aceitos	2015-05-19 10:22:38.010226	pt-br
475	pt-br	*	Lista de todas as metas	Lista de todas as metas	2015-05-19 10:22:38.013548	pt-br
477	en	*	Lista de todas as metas	? Lista de todas as metas	2015-05-19 10:22:38.022331	pt-br
478	pt-br	*	Lista de todos atributos da meta específica	Lista de todos atributos da meta específica	2015-05-19 10:22:38.026421	pt-br
480	en	*	Lista de todos atributos da meta específica	? Lista de todos atributos da meta específica	2015-05-19 10:22:38.033002	pt-br
481	pt-br	*	id da meta	id da meta	2015-05-19 10:22:38.03773	pt-br
483	en	*	id da meta	? id da meta	2015-05-19 10:22:38.047177	pt-br
484	pt-br	*	Lista de todos os projetos	Lista de todos os projetos	2015-05-19 10:22:38.054863	pt-br
486	en	*	Lista de todos os projetos	? Lista de todos os projetos	2015-05-19 10:22:38.066328	pt-br
487	pt-br	*	Lista de todos os atributos do projeto específico	Lista de todos os atributos do projeto específico	2015-05-19 10:22:38.071129	pt-br
726	en	*	Objetivo de entrega	? Objetivo de entrega	2015-05-20 18:31:26.384495	pt-br
489	en	*	Lista de todos os atributos do projeto específico	? Lista de todos os atributos do projeto específico	2015-05-19 10:22:38.079799	pt-br
490	pt-br	*	id do projeto	id do projeto	2015-05-19 10:22:38.083867	pt-br
492	en	*	id do projeto	? id do projeto	2015-05-19 10:22:38.090947	pt-br
493	pt-br	*	Lista de todos os objetivos	Lista de todos os objetivos	2015-05-19 10:22:38.094539	pt-br
495	en	*	Lista de todos os objetivos	? Lista de todos os objetivos	2015-05-19 10:22:38.102429	pt-br
496	pt-br	*	Lista de todas as empresas	Lista de todas as empresas	2015-05-19 10:22:38.109376	pt-br
498	en	*	Lista de todas as empresas	? Lista de todas as empresas	2015-05-19 10:22:38.117694	pt-br
499	pt-br	*	voltar para endpoints	voltar para endpoints	2015-05-19 10:24:07.453445	pt-br
501	en	*	voltar para endpoints	? voltar para endpoints	2015-05-19 10:24:07.463812	pt-br
502	pt-br	*	Lista de todas as empresas por metas de acordo com os orçamentos utilizados	Lista de todas as empresas por metas de acordo com os orçamentos utilizados	2015-05-19 10:30:04.909025	pt-br
504	en	*	Lista de todas as empresas por metas de acordo com os orçamentos utilizados	? Lista de todas as empresas por metas de acordo com os orçamentos utilizados	2015-05-19 10:30:04.919052	pt-br
505	pt-br	*	Lista de todas as empresas por metas	Lista de todas as empresas por metas	2015-05-19 10:30:04.922783	pt-br
507	en	*	Lista de todas as empresas por metas	? Lista de todas as empresas por metas	2015-05-19 10:30:04.930224	pt-br
508	pt-br	*	Lista de todos os conselhos	Lista de todos os conselhos	2015-05-19 10:30:04.934114	pt-br
510	en	*	Lista de todos os conselhos	? Lista de todos os conselhos	2015-05-19 10:30:04.942689	pt-br
511	pt-br	*	Lista de todos os distritos	Lista de todos os distritos	2015-05-19 10:30:04.946393	pt-br
513	en	*	Lista de todos os distritos	? Lista de todos os distritos	2015-05-19 10:30:04.954029	pt-br
514	pt-br	*	Lista de todas as subprefeituras	Lista de todas as subprefeituras	2015-05-19 10:30:04.958325	pt-br
516	en	*	Lista de todas as subprefeituras	? Lista de todas as subprefeituras	2015-05-19 10:30:04.96647	pt-br
517	pt-br	*	Exemplo de retorno	Exemplo de retorno	2015-05-19 10:30:04.970768	pt-br
519	en	*	Exemplo de retorno	? Exemplo de retorno	2015-05-19 10:30:04.977783	pt-br
520	pt-br	*	Selecione o Distrito	Selecione o Distrito	2015-05-19 11:03:10.591503	pt-br
522	en	*	Selecione o Distrito	? Selecione o Distrito	2015-05-19 11:03:10.605326	pt-br
523	pt-br	*	Projetos neste Distrito	Projetos neste Distrito	2015-05-19 11:03:22.214801	pt-br
525	en	*	Projetos neste Distrito	? Projetos neste Distrito	2015-05-19 11:03:22.226947	pt-br
526	pt-br	*	Participe dos Eventos	Participe dos Eventos	2015-05-19 11:03:22.234418	pt-br
528	en	*	Participe dos Eventos	? Participe dos Eventos	2015-05-19 11:03:22.24324	pt-br
529	pt-br	*	Nome da campanha	Nome da campanha	2015-05-19 11:03:22.247281	pt-br
531	en	*	Nome da campanha	? Nome da campanha	2015-05-19 11:03:22.258003	pt-br
532	pt-br	*	Encontre seu distrito	Encontre seu distrito	2015-05-19 11:03:30.527598	pt-br
534	en	*	Encontre seu distrito	? Encontre seu distrito	2015-05-19 11:03:30.537803	pt-br
535	pt-br	*	Conselhos Participativos	Conselhos Participativos	2015-05-19 11:04:17.752901	pt-br
537	en	*	Conselhos Participativos	? Conselhos Participativos	2015-05-19 11:04:17.762405	pt-br
538	pt-br	*	Siga o Conselho	Siga o Conselho	2015-05-19 11:05:04.756371	pt-br
540	en	*	Siga o Conselho	? Siga o Conselho	2015-05-19 11:05:04.765576	pt-br
541	pt-br	*	Conselho participativo	Conselho participativo	2015-05-19 11:05:04.770003	pt-br
543	en	*	Conselho participativo	? Conselho participativo	2015-05-19 11:05:04.779519	pt-br
544	pt-br	*	Total Recebido	Total Recebido	2015-05-19 11:06:11.25573	pt-br
546	en	*	Total Recebido	? Total Recebido	2015-05-19 11:06:11.264414	pt-br
547	pt-br	*	Valor empenhado	Valor empenhado	2015-05-19 11:06:11.267906	pt-br
549	en	*	Valor empenhado	? Valor empenhado	2015-05-19 11:06:11.27625	pt-br
550	pt-br	*	Meta(s) Associada(s)	Meta(s) Associada(s)	2015-05-19 11:06:11.281907	pt-br
552	en	*	Meta(s) Associada(s)	? Meta(s) Associada(s)	2015-05-19 11:06:11.287965	pt-br
553	pt-br	*	Efetuar download das tabelas	Efetuar download das tabelas	2015-05-19 11:06:17.253497	pt-br
555	en	*	Efetuar download das tabelas	? Efetuar download das tabelas	2015-05-19 11:06:17.263089	pt-br
556	pt-br	*	Acesso	Acesso	2015-05-19 11:16:23.018189	pt-br
558	en	*	Acesso	? Acesso	2015-05-19 11:16:23.035226	pt-br
559	pt-br	*	Esqueceu a senha	Esqueceu a senha	2015-05-19 11:16:23.040432	pt-br
561	en	*	Esqueceu a senha	? Esqueceu a senha	2015-05-19 11:16:23.048253	pt-br
823	pt-br	*	NOME:	NOME:	2015-06-04 16:47:32.91913	pt-br
562	pt-br	*	Bem vindo ao sistema De Olho nas Metas. Faça o login ao lado ou cadastre-se através do link abaixo	Bem vindo ao sistema De Olho nas Metas. Faça o login ao lado ou cadastre-se através do link abaixo	2015-05-19 11:16:23.052051	pt-br
564	en	*	Bem vindo ao sistema De Olho nas Metas. Faça o login ao lado ou cadastre-se através do link abaixo	? Bem vindo ao sistema De Olho nas Metas. Faça o login ao lado ou cadastre-se através do link abaixo	2015-05-19 11:16:23.059462	pt-br
565	pt-br	*	Faça seu Cadastro	Faça seu Cadastro	2015-05-19 11:16:23.06301	pt-br
567	en	*	Faça seu Cadastro	? Faça seu Cadastro	2015-05-19 11:16:23.070712	pt-br
568	pt-br	*	Conselheiro? Clique aqui!	Conselheiro? Clique aqui!	2015-05-19 11:16:23.07513	pt-br
563	es	*	Bem vindo ao sistema De Olho nas Metas. Faça o login ao lado ou cadastre-se através do link abaixo	Bien venido al sistema De Ojo en las Metas. Haga el login al lado o registre a través del link abajo	2015-05-19 11:16:23.055926	pt-br
570	en	*	Conselheiro? Clique aqui!	? Conselheiro? Clique aqui!	2015-05-19 11:16:23.081769	pt-br
574	pt-br	*	Notificações Recentes	Notificações Recentes	2015-05-19 11:47:53.482085	pt-br
576	en	*	Notificações Recentes	? Notificações Recentes	2015-05-19 11:47:53.490434	pt-br
577	pt-br	*	Nenhuma notificação	Nenhuma notificação	2015-05-19 11:47:53.498728	pt-br
579	en	*	Nenhuma notificação	? Nenhuma notificação	2015-05-19 11:47:53.506219	pt-br
580	pt-br	*	Atividades recentes	Atividades recentes	2015-05-19 11:47:53.511963	pt-br
582	en	*	Atividades recentes	? Atividades recentes	2015-05-19 11:47:53.52206	pt-br
583	pt-br	*	Cadastrar Campanhas	Cadastrar Campanhas	2015-05-19 11:47:58.208494	pt-br
585	en	*	Cadastrar Campanhas	? Cadastrar Campanhas	2015-05-19 11:47:58.217994	pt-br
586	pt-br	*	Cadastrar Eventos	Cadastrar Eventos	2015-05-19 11:47:58.222187	pt-br
588	en	*	Cadastrar Eventos	? Cadastrar Eventos	2015-05-19 11:47:58.231111	pt-br
589	pt-br	*	CADASTRE UMA NOVA CAMPANHA	CADASTRE UMA NOVA CAMPANHA	2015-05-19 11:47:58.234669	pt-br
591	en	*	CADASTRE UMA NOVA CAMPANHA	? CADASTRE UMA NOVA CAMPANHA	2015-05-19 11:47:58.241461	pt-br
592	pt-br	*	Editar perfil	Editar perfil	2015-05-19 12:25:53.311638	pt-br
594	en	*	Editar perfil	? Editar perfil	2015-05-19 12:25:53.320981	pt-br
595	pt-br	*	Campanha de dados móveis	Campanha de dados móveis	2015-05-19 12:25:53.325862	pt-br
597	en	*	Campanha de dados móveis	? Campanha de dados móveis	2015-05-19 12:25:53.33365	pt-br
598	pt-br	*	Convidar	Convidar	2015-05-19 12:25:53.337567	pt-br
600	en	*	Convidar	? Convidar	2015-05-19 12:25:53.344381	pt-br
601	pt-br	*	Membros do Conselho	Membros do Conselho	2015-05-19 12:25:53.347672	pt-br
603	en	*	Membros do Conselho	? Membros do Conselho	2015-05-19 12:25:53.35496	pt-br
604	pt-br	*	Seguindo	Seguindo	2015-05-19 12:25:53.358534	pt-br
606	en	*	Seguindo	? Seguindo	2015-05-19 12:25:53.367009	pt-br
607	pt-br	*	Segurança	Segurança	2015-05-19 12:25:53.371015	pt-br
609	en	*	Segurança	? Segurança	2015-05-19 12:25:53.378751	pt-br
610	pt-br	*	Email	Email	2015-05-19 14:04:59.910476	pt-br
612	en	*	Email	? Email	2015-05-19 14:04:59.92355	pt-br
613	pt-br	*	Data de cadastro	Data de cadastro	2015-05-19 14:04:59.92768	pt-br
615	en	*	Data de cadastro	? Data de cadastro	2015-05-19 14:04:59.935494	pt-br
616	pt-br	*	FOTO DO PERFIL	FOTO DO PERFIL	2015-05-19 14:10:11.525344	pt-br
618	en	*	FOTO DO PERFIL	? FOTO DO PERFIL	2015-05-19 14:10:11.534902	pt-br
619	pt-br	*	Faça upload de uma foto para usar no seu perfil	Faça upload de uma foto para usar no seu perfil	2015-05-19 14:10:11.539046	pt-br
621	en	*	Faça upload de uma foto para usar no seu perfil	? Faça upload de uma foto para usar no seu perfil	2015-05-19 14:10:11.548129	pt-br
622	pt-br	*	Criar nova campanha móvel	Criar nova campanha móvel	2015-05-19 14:14:38.516291	pt-br
624	en	*	Criar nova campanha móvel	? Criar nova campanha móvel	2015-05-19 14:14:38.525914	pt-br
625	pt-br	*	Sem descrição	Sem descrição	2015-05-19 14:14:38.530069	pt-br
627	en	*	Sem descrição	? Sem descrição	2015-05-19 14:14:38.538376	pt-br
628	pt-br	*	Pausada	Pausada	2015-05-19 14:14:38.544929	pt-br
630	en	*	Pausada	? Pausada	2015-05-19 14:14:38.555434	pt-br
631	pt-br	*	Clonar	Clonar	2015-05-19 14:14:54.821671	pt-br
633	en	*	Clonar	? Clonar	2015-05-19 14:14:54.832483	pt-br
634	pt-br	*	Formulário	Formulário	2015-05-19 14:33:44.136865	pt-br
636	en	*	Formulário	? Formulário	2015-05-19 14:33:44.14622	pt-br
637	pt-br	*	CADASTRE UM NOVO CONSELHEIRO	CADASTRE UM NOVO CONSELHEIRO	2015-05-19 14:33:44.151742	pt-br
639	en	*	CADASTRE UM NOVO CONSELHEIRO	? CADASTRE UM NOVO CONSELHEIRO	2015-05-19 14:33:44.159131	pt-br
640	pt-br	*	CONVIDE UM NOVO CONSELHEIRO POR E-MAIL	CONVIDE UM NOVO CONSELHEIRO POR E-MAIL	2015-05-19 14:33:44.1674	pt-br
642	en	*	CONVIDE UM NOVO CONSELHEIRO POR E-MAIL	? CONVIDE UM NOVO CONSELHEIRO POR E-MAIL	2015-05-19 14:33:44.177212	pt-br
643	pt-br	*	Limpar	Limpar	2015-05-19 14:35:12.489369	pt-br
645	en	*	Limpar	? Limpar	2015-05-19 14:35:12.499761	pt-br
646	pt-br	*	Enviar	Enviar	2015-05-19 14:35:12.503833	pt-br
648	en	*	Enviar	? Enviar	2015-05-19 14:35:12.514015	pt-br
649	pt-br	*	Parar de seguir	Parar de seguir	2015-05-19 14:35:50.905487	pt-br
651	en	*	Parar de seguir	? Parar de seguir	2015-05-19 14:35:50.915829	pt-br
652	pt-br	*	CEP ou Endereço	CEP ou Endereço	2015-05-19 14:36:06.512848	pt-br
654	en	*	CEP ou Endereço	? CEP ou Endereço	2015-05-19 14:36:06.520403	pt-br
655	pt-br	*	Campanha Móvel	Campanha Móvel	2015-05-19 14:36:06.524306	pt-br
657	en	*	Campanha Móvel	? Campanha Móvel	2015-05-19 14:36:06.533852	pt-br
658	pt-br	*	Faça upload de uma imagem para ilustrar a campanha	Faça upload de uma imagem para ilustrar a campanha	2015-05-19 14:36:06.537464	pt-br
660	en	*	Faça upload de uma imagem para ilustrar a campanha	? Faça upload de uma imagem para ilustrar a campanha	2015-05-19 14:36:06.545267	pt-br
661	pt-br	*	Cadastrar	Cadastrar	2015-05-19 14:36:06.551144	pt-br
663	en	*	Cadastrar	? Cadastrar	2015-05-19 14:36:06.557975	pt-br
664	pt-br	*	Selecione	Selecione	2015-05-19 14:36:06.564328	pt-br
666	en	*	Selecione	? Selecione	2015-05-19 14:36:06.572413	pt-br
667	pt-br	*	Faça upload de uma imagem para ilustrar o evento	Faça upload de uma imagem para ilustrar o evento	2015-05-19 14:36:06.576147	pt-br
669	en	*	Faça upload de uma imagem para ilustrar o evento	? Faça upload de uma imagem para ilustrar o evento	2015-05-19 14:36:06.586017	pt-br
670	pt-br	*	CAMPANHAS CADASTRADAS	CAMPANHAS CADASTRADAS	2015-05-19 14:36:06.590611	pt-br
672	en	*	CAMPANHAS CADASTRADAS	? CAMPANHAS CADASTRADAS	2015-05-19 14:36:06.599903	pt-br
673	pt-br	*	Editar	Editar	2015-05-19 14:36:06.605198	pt-br
675	en	*	Editar	? Editar	2015-05-19 14:36:06.613234	pt-br
676	pt-br	*	Remover	Remover	2015-05-19 14:36:06.617393	pt-br
678	en	*	Remover	? Remover	2015-05-19 14:36:06.624869	pt-br
679	pt-br	*	EVENTOS CADASTRADOS	EVENTOS CADASTRADOS	2015-05-19 14:36:06.629647	pt-br
681	en	*	EVENTOS CADASTRADOS	? EVENTOS CADASTRADOS	2015-05-19 14:36:06.638518	pt-br
682	pt-br	*	Início	Início	2015-05-19 14:53:41.562339	pt-br
684	en	*	Início	? Início	2015-05-19 14:53:41.572297	pt-br
685	pt-br	*	Organizações	Organizações	2015-05-19 14:53:41.576674	pt-br
687	en	*	Organizações	? Organizações	2015-05-19 14:53:41.587398	pt-br
688	pt-br	*	Gestões	Gestões	2015-05-19 14:53:41.591896	pt-br
690	en	*	Gestões	? Gestões	2015-05-19 14:53:41.599752	pt-br
691	pt-br	*	Aprovações de Notificações	Aprovações de Notificações	2015-05-19 14:53:41.60562	pt-br
693	en	*	Aprovações de Notificações	? Aprovações de Notificações	2015-05-19 14:53:41.612974	pt-br
694	pt-br	*	Requisições de Conselheiros	Requisições de Conselheiros	2015-05-19 14:53:41.617312	pt-br
696	en	*	Requisições de Conselheiros	? Requisições de Conselheiros	2015-05-19 14:53:41.626567	pt-br
697	pt-br	*	Aprovações de Comentários	Aprovações de Comentários	2015-05-19 14:53:41.63073	pt-br
699	en	*	Aprovações de Comentários	? Aprovações de Comentários	2015-05-19 14:53:41.639852	pt-br
700	pt-br	*	Fale Conosco	Fale Conosco	2015-05-19 14:53:41.644129	pt-br
702	en	*	Fale Conosco	? Fale Conosco	2015-05-19 14:53:41.652406	pt-br
703	pt-br	*	Usuários	Usuários	2015-05-19 14:53:41.658035	pt-br
705	en	*	Usuários	? Usuários	2015-05-19 14:53:41.671846	pt-br
706	pt-br	*	Adicionar nova organização	Adicionar nova organização	2015-05-19 14:53:45.885344	pt-br
708	en	*	Adicionar nova organização	? Adicionar nova organização	2015-05-19 14:53:45.893748	pt-br
709	pt-br	*	Ações	Ações	2015-05-19 14:53:45.898587	pt-br
711	en	*	Ações	? Ações	2015-05-19 14:53:45.906243	pt-br
712	pt-br	*	Excluir	Excluir	2015-05-19 14:53:45.909882	pt-br
714	en	*	Excluir	? Excluir	2015-05-19 14:53:45.918478	pt-br
715	pt-br	*	Orçamento Executado	Orçamento Executado	2015-05-20 18:31:15.41365	pt-br
717	en	*	Orçamento Executado	? Orçamento Executado	2015-05-20 18:31:15.429127	pt-br
718	pt-br	*	Porcentagem Concluída	Porcentagem Concluída	2015-05-20 18:31:15.434765	pt-br
720	en	*	Porcentagem Concluída	? Porcentagem Concluída	2015-05-20 18:31:15.444474	pt-br
721	pt-br	*	Descrição Técnica	Descrição Técnica	2015-05-20 18:31:26.358306	pt-br
723	en	*	Descrição Técnica	? Descrição Técnica	2015-05-20 18:31:26.368343	pt-br
724	pt-br	*	Objetivo de entrega	Objetivo de entrega	2015-05-20 18:31:26.377091	pt-br
727	pt-br	*	E-mail:	E-mail:	2015-05-20 19:48:28.188585	pt-br
729	en	*	E-mail:	? E-mail:	2015-05-20 19:48:28.200942	pt-br
730	pt-br	*	Senha:	Senha:	2015-05-20 19:48:28.205713	pt-br
732	en	*	Senha:	? Senha:	2015-05-20 19:48:28.214825	pt-br
733	pt-br	*	Eventos	Eventos	2015-05-29 11:30:00.187438	pt-br
735	en	*	Eventos	? Eventos	2015-05-29 11:30:00.199419	pt-br
736	pt-br	*	Nome:	Nome:	2015-05-29 11:30:00.205476	pt-br
738	en	*	Nome:	? Nome:	2015-05-29 11:30:00.214107	pt-br
739	pt-br	*	Descrição:	Descrição:	2015-05-29 11:30:00.2191	pt-br
741	en	*	Descrição:	? Descrição:	2015-05-29 11:30:00.225971	pt-br
742	pt-br	*	Objetivo:	Objetivo:	2015-05-29 11:30:00.22966	pt-br
744	en	*	Objetivo:	? Objetivo:	2015-05-29 11:30:00.236918	pt-br
745	pt-br	*	Texto livre:	Texto livre:	2015-05-29 11:30:00.240646	pt-br
747	en	*	Texto livre:	? Texto livre:	2015-05-29 11:30:00.246696	pt-br
748	pt-br	*	Data Começo:	Data Começo:	2015-05-29 11:30:00.251523	pt-br
750	en	*	Data Começo:	? Data Começo:	2015-05-29 11:30:00.259365	pt-br
751	pt-br	*	Data Final:	Data Final:	2015-05-29 11:30:00.263193	pt-br
753	en	*	Data Final:	? Data Final:	2015-05-29 11:30:00.269664	pt-br
754	pt-br	*	Data:	Data:	2015-05-29 11:30:00.275404	pt-br
756	en	*	Data:	? Data:	2015-05-29 11:30:00.282532	pt-br
757	pt-br	*	Faça upload de um arquivo que contenha os dados da meta	Faça upload de um arquivo que contenha os dados da meta	2015-05-29 11:32:10.237321	pt-br
759	en	*	Faça upload de um arquivo que contenha os dados da meta	? Faça upload de um arquivo que contenha os dados da meta	2015-05-29 11:32:10.247495	pt-br
760	pt-br	*	Nenhum orçamento encontrado	Nenhum orçamento encontrado	2015-05-29 15:37:59.422942	pt-br
762	en	*	Nenhum orçamento encontrado	? Nenhum orçamento encontrado	2015-05-29 15:37:59.440441	pt-br
763	pt-br	*	Faça upload de um arquivo que contenha os dados do projeto	Faça upload de um arquivo que contenha os dados do projeto	2015-05-29 17:47:25.28414	pt-br
765	en	*	Faça upload de um arquivo que contenha os dados do projeto	? Faça upload de um arquivo que contenha os dados do projeto	2015-05-29 17:47:25.295903	pt-br
766	pt-br	*	Faça upload de um arquivo que contenha os dados do distrito	Faça upload de um arquivo que contenha os dados do distrito	2015-06-01 13:54:42.658358	pt-br
768	en	*	Faça upload de um arquivo que contenha os dados do distrito	? Faça upload de um arquivo que contenha os dados do distrito	2015-06-01 13:54:42.671972	pt-br
772	pt-br	*	Encontre a campanha	Encontre a campanha	2015-06-03 12:07:21.388773	pt-br
774	en	*	Encontre a campanha	? Encontre a campanha	2015-06-03 12:07:21.637688	pt-br
775	pt-br	*	Filtrar Campanha	Filtrar Campanha	2015-06-03 12:07:21.670858	pt-br
777	en	*	Filtrar Campanha	? Filtrar Campanha	2015-06-03 12:07:21.748673	pt-br
778	pt-br	*	Participe das campanhas	Participe das campanhas	2015-06-03 12:07:21.787917	pt-br
780	en	*	Participe das campanhas	? Participe das campanhas	2015-06-03 12:07:21.835283	pt-br
781	pt-br	*	Nenhum valor encontrado	Nenhum valor encontrado	2015-06-03 12:07:51.548435	pt-br
783	en	*	Nenhum valor encontrado	? Nenhum valor encontrado	2015-06-03 12:07:51.830947	pt-br
784	pt-br	*	PROCURAR EMPRESAS	PROCURAR EMPRESAS	2015-06-03 14:50:07.901496	pt-br
786	en	*	PROCURAR EMPRESAS	? PROCURAR EMPRESAS	2015-06-03 14:50:08.230048	pt-br
787	pt-br	*	Informe o Nome	Informe o Nome	2015-06-03 14:50:08.253674	pt-br
789	en	*	Informe o Nome	? Informe o Nome	2015-06-03 14:50:08.299674	pt-br
790	pt-br	*	FILTRAR EMPRESAS POR	FILTRAR EMPRESAS POR	2015-06-03 14:50:08.323338	pt-br
792	en	*	FILTRAR EMPRESAS POR	? FILTRAR EMPRESAS POR	2015-06-03 14:50:08.370142	pt-br
793	pt-br	*	Organizações Encontradas	Organizações Encontradas	2015-06-03 14:50:08.394309	pt-br
795	en	*	Organizações Encontradas	? Organizações Encontradas	2015-06-03 14:50:08.50434	pt-br
796	pt-br	*	*Nome:	*Nome:	2015-06-04 08:56:00.994572	pt-br
798	en	*	*Nome:	? *Nome:	2015-06-04 08:56:01.401541	pt-br
799	pt-br	*	*E-mail (será seu acesso ao sistema):	*E-mail (será seu acesso ao sistema):	2015-06-04 08:56:01.442542	pt-br
801	en	*	*E-mail (será seu acesso ao sistema):	? *E-mail (será seu acesso ao sistema):	2015-06-04 08:56:01.515728	pt-br
802	pt-br	*	*Criar uma senha:	*Criar uma senha:	2015-06-04 08:56:01.543455	pt-br
804	en	*	*Criar uma senha:	? *Criar uma senha:	2015-06-04 08:56:01.588125	pt-br
805	pt-br	*	*Confirme a senha:	*Confirme a senha:	2015-06-04 08:56:01.613236	pt-br
807	en	*	*Confirme a senha:	? *Confirme a senha:	2015-06-04 08:56:01.656786	pt-br
808	pt-br	*	Celular:	Celular:	2015-06-04 08:56:01.682582	pt-br
810	en	*	Celular:	? Celular:	2015-06-04 08:56:01.727458	pt-br
811	pt-br	*	Atividades	Atividades	2015-06-04 08:58:18.626158	pt-br
813	en	*	Atividades	? Atividades	2015-06-04 08:58:18.745857	pt-br
814	pt-br	*	*E-mail:	*E-mail:	2015-06-04 16:24:52.928243	pt-br
816	en	*	*E-mail:	? *E-mail:	2015-06-04 16:24:53.118132	pt-br
817	pt-br	*	*Celular:	*Celular:	2015-06-04 16:24:53.152529	pt-br
819	en	*	*Celular:	? *Celular:	2015-06-04 16:24:53.198416	pt-br
820	pt-br	*	*Conselho participativo de que é membro:	*Conselho participativo de que é membro:	2015-06-04 16:24:53.223904	pt-br
822	en	*	*Conselho participativo de que é membro:	? *Conselho participativo de que é membro:	2015-06-04 16:24:53.286607	pt-br
832	pt-br	*	Enviado por	Enviado por	2015-06-04 17:28:42.688269	pt-br
834	en	*	Enviado por	? Enviado por	2015-06-04 17:28:42.881752	pt-br
809	es	*	Celular:	Celular:	2015-06-04 08:56:01.702495	pt-br
812	es	*	Atividades	Actividades	2015-06-04 08:58:18.69914	pt-br
815	es	*	*E-mail:	*E-mail:	2015-06-04 16:24:53.09551	pt-br
818	es	*	*Celular:	*Celular:	2015-06-04 16:24:53.174555	pt-br
821	es	*	*Conselho participativo de que é membro:	*Consejo participativo del que es miembro:	2015-06-04 16:24:53.263082	pt-br
833	es	*	Enviado por	Enviado por	2015-06-04 17:28:42.860754	pt-br
825	en	*	NOME:	? NOME:	2015-06-04 16:47:33.433901	pt-br
826	pt-br	*	E-MAIL:	E-MAIL:	2015-06-04 16:47:33.579901	pt-br
828	en	*	E-MAIL:	? E-MAIL:	2015-06-04 16:47:33.744925	pt-br
829	pt-br	*	Nenhum progresso até o momento	Nenhum progresso até o momento	2015-06-04 17:03:51.281732	pt-br
831	en	*	Nenhum progresso até o momento	? Nenhum progresso até o momento	2015-06-04 17:03:51.920179	pt-br
835	pt-br	*	NENHUM PROJETO NA REGIÃO	NENHUM PROJETO NA REGIÃO	2015-06-05 16:17:18.05364	pt-br
837	en	*	NENHUM PROJETO NA REGIÃO	? NENHUM PROJETO NA REGIÃO	2015-06-05 16:17:18.421635	pt-br
838	pt-br	*	NENHUMA REGIÃO ENCONTRADA	NENHUMA REGIÃO ENCONTRADA	2015-06-07 00:39:28.255904	pt-br
840	en	*	NENHUMA REGIÃO ENCONTRADA	? NENHUMA REGIÃO ENCONTRADA	2015-06-07 00:39:28.592954	pt-br
841	pt-br	*	Valor dedicado	Valor dedicado	2015-06-08 11:36:40.020174	pt-br
843	en	*	Valor dedicado	? Valor dedicado	2015-06-08 11:36:40.396785	pt-br
844	pt-br	*	Código de empenho	Código de empenho	2015-06-08 11:36:40.431786	pt-br
846	en	*	Código de empenho	? Código de empenho	2015-06-08 11:36:40.54659	pt-br
847	pt-br	*	Participe das Campanhas	Participe das Campanhas	2015-06-08 13:57:18.61834	pt-br
849	en	*	Participe das Campanhas	? Participe das Campanhas	2015-06-08 13:57:18.753858	pt-br
850	pt-br	*	Campanha	Campanha	2015-06-08 19:59:22.532626	pt-br
852	en	*	Campanha	? Campanha	2015-06-08 19:59:22.719813	pt-br
853	pt-br	*	NENHUM EVENTO ENCONTRADO	NENHUM EVENTO ENCONTRADO	2015-06-08 19:59:22.743949	pt-br
855	en	*	NENHUM EVENTO ENCONTRADO	? NENHUM EVENTO ENCONTRADO	2015-06-08 19:59:22.790989	pt-br
856	pt-br	*	O projeto	O projeto	2015-06-10 16:19:01.815388	pt-br
858	en	*	O projeto	? O projeto	2015-06-10 16:19:01.98764	pt-br
859	pt-br	*	foi atualizado	foi atualizado	2015-06-10 16:19:02.015686	pt-br
861	en	*	foi atualizado	? foi atualizado	2015-06-10 16:19:02.152239	pt-br
862	pt-br	*	Avaliação dos conselheiros sobre o andamento do projeto	Avaliação dos conselheiros sobre o andamento do projeto	2015-06-10 16:20:09.134876	pt-br
864	en	*	Avaliação dos conselheiros sobre o andamento do projeto	? Avaliação dos conselheiros sobre o andamento do projeto	2015-06-10 16:20:09.221662	pt-br
865	pt-br	*	Qual sua avaliação a respeito do projeto? Selecione uma das opções abaixo	Qual sua avaliação a respeito do projeto? Selecione uma das opções abaixo	2015-06-10 16:20:09.246593	pt-br
867	en	*	Qual sua avaliação a respeito do projeto? Selecione uma das opções abaixo	? Qual sua avaliação a respeito do projeto? Selecione uma das opções abaixo	2015-06-10 16:20:09.293146	pt-br
868	pt-br	*	Atrasado	Atrasado	2015-06-10 16:20:09.315851	pt-br
870	en	*	Atrasado	? Atrasado	2015-06-10 16:20:09.362445	pt-br
871	pt-br	*	Em progresso	Em progresso	2015-06-10 16:20:09.385761	pt-br
873	en	*	Em progresso	? Em progresso	2015-06-10 16:20:09.432735	pt-br
874	pt-br	*	Completo	Completo	2015-06-10 16:20:09.456594	pt-br
876	en	*	Completo	? Completo	2015-06-10 16:20:09.50397	pt-br
877	pt-br	*	Senha Atual	Senha Atual	2015-06-22 10:31:34.38552	pt-br
879	en	*	Senha Atual	? Senha Atual	2015-06-22 10:31:34.6417	pt-br
880	pt-br	*	Nova Senha	Nova Senha	2015-06-22 10:31:34.671132	pt-br
882	en	*	Nova Senha	? Nova Senha	2015-06-22 10:31:34.757422	pt-br
883	pt-br	*	Confirme Nova Senha	Confirme Nova Senha	2015-06-22 10:31:34.781359	pt-br
885	en	*	Confirme Nova Senha	? Confirme Nova Senha	2015-06-22 10:31:34.895821	pt-br
886	pt-br	*	Valor inválido	Valor inválido	2015-06-22 10:32:02.103411	pt-br
888	en	*	Valor inválido	? Valor inválido	2015-06-22 10:32:02.170329	pt-br
889	pt-br	*	Confirmação de senha	Confirmação de senha	2015-06-22 10:43:21.314403	pt-br
891	en	*	Confirmação de senha	? Confirmação de senha	2015-06-22 10:43:21.411438	pt-br
892	pt-br	*	Nenhuma campanha cadastrada	Nenhuma campanha cadastrada	2015-06-22 10:49:38.472484	pt-br
894	en	*	Nenhuma campanha cadastrada	? Nenhuma campanha cadastrada	2015-06-22 10:49:38.539313	pt-br
895	pt-br	*	Nenhum evento cadastrado	Nenhum evento cadastrado	2015-06-22 10:49:38.577965	pt-br
897	en	*	Nenhum evento cadastrado	? Nenhum evento cadastrado	2015-06-22 10:49:38.624313	pt-br
898	pt-br	*	Este campo não pode ser vazio	Este campo não pode ser vazio	2015-06-29 08:10:28.261536	pt-br
900	en	*	Este campo não pode ser vazio	? Este campo não pode ser vazio	2015-06-29 08:10:28.579426	pt-br
901	pt-br	*	Modelo de arquivo para preenchimento	Modelo de arquivo para preenchimento	2015-06-30 16:33:48.17878	pt-br
903	en	*	Modelo de arquivo para preenchimento	? Modelo de arquivo para preenchimento	2015-06-30 16:33:48.438195	pt-br
904	pt-br	*	Tabelas dependentes	Tabelas dependentes	2015-06-30 16:33:48.463559	pt-br
869	es	*	Atrasado	Tarde	2015-06-10 16:20:09.339609	pt-br
905	es	*	Tabelas dependentes	? Tabelas dependentes	2015-06-30 16:33:48.510544	pt-br
906	en	*	Tabelas dependentes	? Tabelas dependentes	2015-06-30 16:33:48.533563	pt-br
907	pt-br	*	METAS	METAS	2015-06-30 16:33:48.557658	pt-br
909	en	*	METAS	? METAS	2015-06-30 16:33:48.603538	pt-br
910	pt-br	*	REGIÕES	REGIÕES	2015-06-30 16:33:48.627401	pt-br
912	en	*	REGIÕES	? REGIÕES	2015-06-30 16:33:48.698557	pt-br
913	pt-br	*	Importar Arquivo	Importar Arquivo	2015-06-30 16:33:48.722225	pt-br
915	en	*	Importar Arquivo	? Importar Arquivo	2015-06-30 16:33:48.768576	pt-br
916	pt-br	*	Opiniões dos conselheiros sobre o progresso	Opiniões dos conselheiros sobre o progresso	2015-07-13 16:48:33.52972	pt-br
917	es	*	Opiniões dos conselheiros sobre o progresso	? Opiniões dos conselheiros sobre o progresso	2015-07-13 16:48:33.63917	pt-br
918	en	*	Opiniões dos conselheiros sobre o progresso	? Opiniões dos conselheiros sobre o progresso	2015-07-13 16:48:33.660563	pt-br
919	pt-br	*	imagens relacionadas	imagens relacionadas	2015-07-13 16:48:33.684423	pt-br
920	es	*	imagens relacionadas	? imagens relacionadas	2015-07-13 16:48:33.771901	pt-br
921	en	*	imagens relacionadas	? imagens relacionadas	2015-07-13 16:48:33.794404	pt-br
922	pt-br	*	EDITAR CONSELHO	EDITAR CONSELHO	2015-07-20 17:10:27.38692	pt-br
923	es	*	EDITAR CONSELHO	? EDITAR CONSELHO	2015-07-20 17:10:27.525582	pt-br
924	en	*	EDITAR CONSELHO	? EDITAR CONSELHO	2015-07-20 17:10:27.621931	pt-br
925	pt-br	*	Endereço:	Endereço:	2015-07-20 17:10:27.679052	pt-br
926	es	*	Endereço:	? Endereço:	2015-07-20 17:10:27.71606	pt-br
927	en	*	Endereço:	? Endereço:	2015-07-20 17:10:27.756085	pt-br
928	pt-br	*	Email:	Email:	2015-07-20 17:10:27.779391	pt-br
929	es	*	Email:	? Email:	2015-07-20 17:10:27.824827	pt-br
930	en	*	Email:	? Email:	2015-07-20 17:10:27.847047	pt-br
931	pt-br	*	Site:	Site:	2015-07-20 17:10:27.888011	pt-br
932	es	*	Site:	? Site:	2015-07-20 17:10:27.916806	pt-br
933	en	*	Site:	? Site:	2015-07-20 17:10:27.939139	pt-br
934	pt-br	*	Telefone:	Telefone:	2015-07-20 17:10:27.964118	pt-br
935	es	*	Telefone:	? Telefone:	2015-07-20 17:10:27.996191	pt-br
936	en	*	Telefone:	? Telefone:	2015-07-20 17:10:28.192891	pt-br
937	pt-br	*	Ativo	Ativo	2015-07-20 17:38:14.704346	pt-br
938	es	*	Ativo	? Ativo	2015-07-20 17:38:14.736094	pt-br
939	en	*	Ativo	? Ativo	2015-07-20 17:38:14.811679	pt-br
940	pt-br	*	Ver detalhes	Ver detalhes	2015-07-20 17:38:14.840423	pt-br
941	es	*	Ver detalhes	? Ver detalhes	2015-07-20 17:38:14.864302	pt-br
942	en	*	Ver detalhes	? Ver detalhes	2015-07-20 17:38:14.887727	pt-br
943	pt-br	*	Data Início	Data Início	2015-07-21 10:21:41.747382	pt-br
944	es	*	Data Início	? Data Início	2015-07-21 10:21:42.145296	pt-br
945	en	*	Data Início	? Data Início	2015-07-21 10:21:42.202315	pt-br
946	pt-br	*	Expectativa Data Final	Expectativa Data Final	2015-07-21 10:21:42.227299	pt-br
947	es	*	Expectativa Data Final	? Expectativa Data Final	2015-07-21 10:21:42.300257	pt-br
948	en	*	Expectativa Data Final	? Expectativa Data Final	2015-07-21 10:21:42.3234	pt-br
949	pt-br	*	Distrito(s)	Distrito(s)	2015-07-29 08:02:29.65819	pt-br
950	es	*	Distrito(s)	? Distrito(s)	2015-07-29 08:02:30.010256	pt-br
951	en	*	Distrito(s)	? Distrito(s)	2015-07-29 08:02:30.063972	pt-br
952	pt-br	*	Não está seguindo nenhum conselho	Não está seguindo nenhum conselho	2015-08-06 11:59:19.099315	pt-br
953	es	*	Não está seguindo nenhum conselho	? Não está seguindo nenhum conselho	2015-08-06 11:59:19.412933	pt-br
954	en	*	Não está seguindo nenhum conselho	? Não está seguindo nenhum conselho	2015-08-06 11:59:19.514505	pt-br
955	pt-br	*	Nenhuma campanha móvel encontrada	Nenhuma campanha móvel encontrada	2015-08-06 12:09:18.487786	pt-br
956	es	*	Nenhuma campanha móvel encontrada	? Nenhuma campanha móvel encontrada	2015-08-06 12:09:18.561305	pt-br
957	en	*	Nenhuma campanha móvel encontrada	? Nenhuma campanha móvel encontrada	2015-08-06 12:09:18.591011	pt-br
958	pt-br	*	por Tipo de Conselho	por Tipo de Conselho	2015-08-06 15:31:02.163069	pt-br
959	es	*	por Tipo de Conselho	? por Tipo de Conselho	2015-08-06 15:31:02.482722	pt-br
960	en	*	por Tipo de Conselho	? por Tipo de Conselho	2015-08-06 15:31:02.829829	pt-br
961	pt-br	*	Tipo de Conselho	Tipo de Conselho	2015-08-06 15:31:03.378837	pt-br
962	es	*	Tipo de Conselho	? Tipo de Conselho	2015-08-06 15:31:03.436647	pt-br
963	en	*	Tipo de Conselho	? Tipo de Conselho	2015-08-06 15:31:03.508384	pt-br
964	pt-br	*	Conselho(s)	Conselho(s)	2015-08-06 15:31:03.570184	pt-br
965	es	*	Conselho(s)	? Conselho(s)	2015-08-06 15:31:03.656173	pt-br
966	en	*	Conselho(s)	? Conselho(s)	2015-08-06 15:31:03.685629	pt-br
967	pt-br	*	Nenhum conselho encontrado	Nenhum conselho encontrado	2015-08-06 16:05:00.59101	pt-br
968	es	*	Nenhum conselho encontrado	? Nenhum conselho encontrado	2015-08-06 16:05:00.751237	pt-br
969	en	*	Nenhum conselho encontrado	? Nenhum conselho encontrado	2015-08-06 16:05:00.773397	pt-br
970	pt-br	*	Adicionar organização	Adicionar organização	2015-08-06 17:43:24.18421	pt-br
971	es	*	Adicionar organização	? Adicionar organização	2015-08-06 17:43:24.27697	pt-br
972	en	*	Adicionar organização	? Adicionar organização	2015-08-06 17:43:24.299638	pt-br
973	pt-br	*	Website	Website	2015-08-06 17:43:24.327036	pt-br
974	es	*	Website	? Website	2015-08-06 17:43:24.354821	pt-br
975	en	*	Website	? Website	2015-08-06 17:43:24.37791	pt-br
976	pt-br	*	Número	Número	2015-08-06 17:43:24.405126	pt-br
977	es	*	Número	? Número	2015-08-06 17:43:24.433527	pt-br
978	en	*	Número	? Número	2015-08-06 17:43:24.457058	pt-br
979	pt-br	*	Salvar	Salvar	2015-08-06 17:43:24.486141	pt-br
980	es	*	Salvar	? Salvar	2015-08-06 17:43:24.512161	pt-br
981	en	*	Salvar	? Salvar	2015-08-06 17:43:24.535598	pt-br
2	es	*	Metas	Metas	2015-05-15 10:57:09.309657	pt-br
5	es	*	Distritos	Distritos	2015-05-15 10:57:09.325803	pt-br
8	es	*	Conselhos	Consejos	2015-05-15 10:57:09.339173	pt-br
11	es	*	Campanhas	Campañas	2015-05-15 10:57:09.350908	pt-br
14	es	*	Empresas	Empresas	2015-05-15 11:03:35.627594	pt-br
17	es	*	Dados Abertos	Datos Abiertos	2015-05-15 11:03:35.639229	pt-br
20	es	*	Entrar	Ingresar	2015-05-15 11:03:35.651527	pt-br
23	es	*	Sobre	Sobre	2015-05-15 11:03:35.662247	pt-br
26	es	*	Perguntas Frequentes	Preguntas Frecuentes	2015-05-15 11:03:35.673156	pt-br
29	es	*	Contato	Contrato	2015-05-15 11:03:35.683436	pt-br
32	es	*	Cadastro	Registro	2015-05-15 11:03:35.695107	pt-br
35	es	*	Parceiros	Socios	2015-05-15 11:03:35.705676	pt-br
38	es	*	Desenvolvimento	Desarrollo	2015-05-15 11:03:35.716987	pt-br
41	es	*	Meta Associada	Meta Relacionada	2015-05-15 11:05:21.716495	pt-br
44	es	*	Nenhum projeto encontrado	Ningún proyecto encontrado	2015-05-15 11:05:21.729536	pt-br
47	es	*	Projeto{{#plural}}s{{/plural}}	Proyecto{{#plural}}s{{/plural}}	2015-05-15 11:09:47.795787	pt-br
50	es	*	Ajude a monitorar as Metas da cidade de São Paulo	Ayude a monitorear las metas de Ciudad de São Paulo	2015-05-15 11:09:47.808017	pt-br
53	es	*	Use os filtros abaixo para ver os projetos no mapa	Usa los filtros de abajo para ver los proyectos en el mapa	2015-05-15 11:09:47.818237	pt-br
59	es	*	por Distrito	Por Distrito	2015-05-15 11:09:47.84242	pt-br
62	es	*	por Tema	Por Tema	2015-05-15 11:09:47.85537	pt-br
65	es	*	Temas	Temas	2015-05-15 11:09:47.865475	pt-br
68	es	*	Pesquisar	Buscar	2015-05-15 11:10:12.474698	pt-br
71	es	*	Realização	Logro	2015-05-15 11:11:35.546479	pt-br
74	es	*	Apoio	Apoyo	2015-05-15 11:11:35.558869	pt-br
77	es	*	Desenvolvido por	Desarrollado por	2015-05-15 11:11:35.568625	pt-br
80	es	*	Projeto{{#plural}}s{{/plural}} Encontrado{{#plural}}s{{/plural}}	Proyecto{{#plural}}s{{/plural}} Encontrado{{#plural}}s{{/plural}}	2015-05-15 11:13:25.281916	pt-br
83	es	*	Meta	Meta	2015-05-15 11:51:01.490799	pt-br
86	es	*	Regiões	Regiones	2015-05-15 11:51:01.50096	pt-br
89	es	*	Projetos	Proyectos	2015-05-15 11:51:01.51087	pt-br
92	es	*	Distrito	Distrito	2015-05-15 11:51:01.524257	pt-br
95	es	*	Tweetar	Tuitear	2015-05-15 11:51:01.539959	pt-br
98	es	*	INVESTIMENTO TOTAL PREVISTO	INVERSIÓN TOTAL PREVISTA	2015-05-15 11:51:01.552259	pt-br
101	es	*	Linha do tempo segundo o cronograma	Línea de tiempo según cronograma	2015-05-15 11:51:01.562183	pt-br
104	es	*	Progresso de acordo com a prefeitura	Nivel de progreso de la meta	2015-05-15 11:51:01.572414	pt-br
107	es	*	Clique aqui	Cliquee aquí	2015-05-15 11:51:01.586041	pt-br
110	es	*	para acompanhar o andamento do projeto no site Planeja Sampa	realizar el seguimiento del progreso del proyecto en el sitio planeado Sampa	2015-05-15 11:51:01.597371	pt-br
113	es	*	de 6 etapas completas	de 6 etapas completas	2015-05-15 11:51:01.607261	pt-br
116	es	*	Progresso segundo o Conselho Participativo	Progreso según el Consejo Participativo	2015-05-15 11:51:01.619728	pt-br
119	es	*	Fonte das informações	Fuente de información	2015-05-15 11:51:01.631224	pt-br
125	es	*	Nome da Empresa	Nombre de la Empresa	2015-05-15 11:51:01.653605	pt-br
128	es	*	Descrição da despesa	Descripción de la Empresa	2015-05-15 11:51:01.665271	pt-br
131	es	*	Valor Empenhado	Monto Adjudicado	2015-05-15 11:51:01.676582	pt-br
134	es	*	Valor Liquidado	Monto Liquidado	2015-05-15 11:51:01.688306	pt-br
137	es	*	Comentários	Comentarios	2015-05-15 11:51:01.711848	pt-br
140	es	*	Nome	Nombre 	2015-05-15 11:51:01.723125	pt-br
143	es	*	Comentário	Comentario	2015-05-15 11:51:01.737063	pt-br
146	es	*	Data	Dato	2015-05-15 11:51:01.754247	pt-br
149	es	*	Nenhum comentário encontrado	Ningún comentario encontrado	2015-05-15 11:51:01.767971	pt-br
152	es	*	Comentar	Comentar	2015-05-15 11:51:01.779764	pt-br
155	es	*	Tema	Tema	2015-05-15 11:51:01.791271	pt-br
158	es	*	Planeja Sampa	Metas de São Paulo	2015-05-15 11:51:01.80311	pt-br
161	es	*	Empresa	Empresa	2015-05-15 11:51:01.81417	pt-br
164	es	*	Relacionada	Relacionada	2015-05-15 11:51:01.825734	pt-br
167	es	*	Meta(s) Encontrada(s)	Meta(s) Encontrada(s)	2015-05-15 11:58:23.704194	pt-br
173	es	*	Metas Encontradas	Metas Encontradas	2015-05-15 11:58:23.729388	pt-br
176	es	*	Projeto(s)	Proyecto(s)	2015-05-15 11:58:23.742797	pt-br
179	es	*	Região	Región/ Podríamos poner ciudad???	2015-05-15 11:58:43.913481	pt-br
182	es	*	Parar de Seguir	Dejar de seguir	2015-05-15 13:23:31.642339	pt-br
185	es	*	Siga o Projeto	Seguir el Proyecto	2015-05-15 13:23:31.652978	pt-br
188	es	*	Projeto	Proyecto	2015-05-15 13:23:31.671135	pt-br
191	es	*	Acompanhar e receber notificações por email de cada atualização	Recibir notificaciones de las actualizaciones	2015-05-15 13:23:31.682149	pt-br
194	es	*	Comentários dos conselheiros	Comentarios de Consejeros	2015-05-15 13:23:31.694295	pt-br
197	es	*	Conselheiro	Consejero	2015-05-15 13:23:31.70486	pt-br
200	es	*	Adicionar...	Agregar	2015-05-15 13:23:31.716062	pt-br
203	es	*	Iniciar	Iniciar	2015-05-15 13:23:31.727699	pt-br
206	es	*	Cancelar	Cancelar	2015-05-15 13:23:31.738209	pt-br
209	es	*	Fechar	Fechar	2015-05-15 13:23:31.748812	pt-br
212	es	*	Processando...	Procesando…	2015-05-15 13:23:31.764112	pt-br
215	es	*	Erro	Error	2015-05-15 13:23:31.776689	pt-br
218	es	*	Apagar	Apagar	2015-05-15 13:23:31.788724	pt-br
221	es	*	Perfil e ferramentas	Perfil y herramientas	2015-05-15 13:24:02.952933	pt-br
224	es	*	Meu Perfil	Mi Perfil	2015-05-15 13:24:02.963637	pt-br
227	es	*	Sair	Salir	2015-05-15 13:24:02.980237	pt-br
230	es	*	Opinião dos conselheiros sobre o progresso do projeto	Opinión de consejeros sobre el preogreso de la meta o ¿va proyecto?	2015-05-15 13:24:41.081539	pt-br
233	es	*	Nenhuma imagem cadastrada	No hay imágenes registradas	2015-05-15 13:24:41.095283	pt-br
236	es	*	Dados abertos	Datos abiertos	2015-05-19 10:22:37.084751	pt-br
239	es	*	O que são dados abertos	¿Qué son datos abiertos?	2015-05-19 10:22:37.099034	pt-br
320	es	*	Progresso Qualitativo 1	Progreso cualitativo 1	2015-05-19 10:22:37.415046	pt-br
248	es	*	Você pode saber mais sobre o assunto acessando	Usted puede saber más entrando	2015-05-19 10:22:37.136207	pt-br
251	es	*	o Portal de dados abertos do Brasil	El portal de datos abiertos en Brasil	2015-05-19 10:22:37.147533	pt-br
254	es	*	API para desenvolvedores	API para desarrolladores	2015-05-19 10:22:37.158609	pt-br
257	es	*	Você também pode consultar os dados que estão armazenados no DONM via API	También puede consultar los datos que se almacena en DONM través de la API	2015-05-19 10:22:37.168475	pt-br
263	es	*	Baixar arquivos	Bajar archivos	2015-05-19 10:22:37.190369	pt-br
266	es	*	Tabelas	Tablas	2015-05-19 10:22:37.202213	pt-br
269	es	*	Objetivos	Objetivos	2015-05-19 10:22:37.220294	pt-br
272	es	*	Orçamentos	Presupuestos	2015-05-19 10:22:37.232403	pt-br
275	es	*	Subprefeituras	Subprefecturas	2015-05-19 10:22:37.243713	pt-br
278	es	*	Formato	Formato	2015-05-19 10:22:37.254912	pt-br
281	es	*	Links	Links	2015-05-19 10:22:37.264588	pt-br
284	es	*	Arquivo das tabelas	Archivo de Tablas	2015-05-19 10:22:37.27491	pt-br
287	es	*	Informações contidas nos arquivos	La información contenida en los archivos	2015-05-19 10:22:37.286426	pt-br
290	es	*	Campos dos arquivos	Cursos de archivos	2015-05-19 10:22:37.296863	pt-br
293	es	*	ID da meta	ID de la meta	2015-05-19 10:22:37.307984	pt-br
296	es	*	Descrição	Descripción	2015-05-19 10:22:37.318074	pt-br
299	es	*	Orçamento esperado	Presupuesto previsto	2015-05-19 10:22:37.328018	pt-br
302	es	*	Número da meta	Número de Meta	2015-05-19 10:22:37.339669	pt-br
305	es	*	Data de atualização	Fecha de actualización	2015-05-19 10:22:37.350984	pt-br
308	es	*	Data esperada para início	Fecha esperada de inicio	2015-05-19 10:22:37.361642	pt-br
311	es	*	Data esperada para termino	Fecha esperada para la finalización	2015-05-19 10:22:37.376921	pt-br
317	es	*	Transversalidade	Transversalidad	2015-05-19 10:22:37.401701	pt-br
323	es	*	Progresso Qualitativo 2	Progreso Cualitativo 2	2015-05-19 10:22:37.425574	pt-br
326	es	*	Progresso Qualitativo 3	Progreso Cualitativo 3	2015-05-19 10:22:37.436936	pt-br
329	es	*	Progresso Qualitativo 4	Progreso Cualitativo 4	2015-05-19 10:22:37.448956	pt-br
332	es	*	Progresso Qualitativo 5	Progreso Cualitativo 5	2015-05-19 10:22:37.463391	pt-br
335	es	*	Progresso Qualitativo 6	Progreso Cualitativo 6	2015-05-19 10:22:37.475282	pt-br
338	es	*	Objetivo	Objetivo	2015-05-19 10:22:37.486573	pt-br
341	es	*	ID do objetivo	ID del objetivo	2015-05-19 10:22:37.496273	pt-br
344	es	*	ID do projeto	ID del proyecto	2015-05-19 10:22:37.505777	pt-br
347	es	*	latitude	latitud	2015-05-19 10:22:37.51628	pt-br
350	es	*	longitude	longitud	2015-05-19 10:22:37.530323	pt-br
353	es	*	Número do projeto	Número de Proyecto	2015-05-19 10:22:37.5432	pt-br
356	es	*	Porcentagem	Porcentaje	2015-05-19 10:22:37.557787	pt-br
359	es	*	ID da empresa	ID de la empresa	2015-05-19 10:22:37.567968	pt-br
362	es	*	Url do nome	Url del nombre	2015-05-19 10:22:37.578925	pt-br
365	es	*	Orçamento	Presupuesto	2015-05-19 10:22:37.59072	pt-br
368	es	*	ID do orçamento	ID del presupuesto	2015-05-19 10:22:37.60013	pt-br
371	es	*	Nome da empresa	Nombre de la Empresa	2015-05-19 10:22:37.609312	pt-br
377	es	*	Valor Dedicado	Importe Adjudicado	2015-05-19 10:22:37.633708	pt-br
380	es	*	Valor liquidado	Importe liquidado	2015-05-19 10:22:37.644497	pt-br
383	es	*	Observação	Observación	2015-05-19 10:22:37.657621	pt-br
386	es	*	Código de contrato	Código de contrato	2015-05-19 10:22:37.669426	pt-br
389	es	*	Código da organização	Código de la organización	2015-05-19 10:22:37.681298	pt-br
392	es	*	Nome da organização	Nombre de la Organización	2015-05-19 10:22:37.699159	pt-br
395	es	*	Id da empresa	ID de la empresa	2015-05-19 10:22:37.711139	pt-br
398	es	*	Conselho	Consejo	2015-05-19 10:22:37.728144	pt-br
401	es	*	ID do conselho	ID del consejo	2015-05-19 10:22:37.741601	pt-br
404	es	*	Nome do conselho	Nombre del Consejo	2015-05-19 10:22:37.752168	pt-br
407	es	*	Telefone	Teléfono	2015-05-19 10:22:37.761333	pt-br
410	es	*	Endereço	Dirección	2015-05-19 10:22:37.772558	pt-br
413	es	*	Complemento	Complemento	2015-05-19 10:22:37.781904	pt-br
416	es	*	Código postal	Código Postal	2015-05-19 10:22:37.791048	pt-br
419	es	*	Site	Sitio	2015-05-19 10:22:37.800423	pt-br
422	es	*	ID do distrito	ID del Distrito	2015-05-19 10:22:37.814699	pt-br
425	es	*	Nome do distrito	Nombre del Distrito	2015-05-19 10:22:37.836799	pt-br
428	es	*	Latitude	Latitud	2015-05-19 10:22:37.849407	pt-br
431	es	*	Longitude	Longitud	2015-05-19 10:22:37.861005	pt-br
434	es	*	Coordenadas Geométricas	Coordenadas Geométricas	2015-05-19 10:22:37.870703	pt-br
437	es	*	Subprefeitura	Subprefectura	2015-05-19 10:22:37.879879	pt-br
440	es	*	ID da subprefeitura	ID de la subprefectura	2015-05-19 10:22:37.892657	pt-br
443	es	*	Nome da subprefeitura	Nombre de la subprefectura	2015-05-19 10:22:37.902296	pt-br
446	es	*	E-mail	E-mail	2015-05-19 10:22:37.911902	pt-br
449	es	*	Subprefeito	Subprefeito	2015-05-19 10:22:37.924291	pt-br
452	es	*	O DONM fornece uma REST API para a consulta dos dados	El DONM proporciona una API REST para los datos de búsqueda	2015-05-19 10:22:37.934712	pt-br
455	es	*	Os <b>endpoints</b> podem entregar o contéudo serializado em	Los <b> endpoints < / b > pueden entregar el contenido serializado en	2015-05-19 10:22:37.944546	pt-br
458	es	*	O	O	2015-05-19 10:22:37.955288	pt-br
461	es	*	é definido automaticamente pelo header	Se ajusta automáticamente	2015-05-19 10:22:37.96588	pt-br
473	es	*	Parâmetros aceitos	Parametros aceptados	2015-05-19 10:22:38.006763	pt-br
476	es	*	Lista de todas as metas	Lista de todas las metas	2015-05-19 10:22:38.017888	pt-br
479	es	*	Lista de todos atributos da meta específica	Lista de todos los atributos de la meta específica	2015-05-19 10:22:38.029595	pt-br
482	es	*	id da meta	ID de la meta	2015-05-19 10:22:38.042257	pt-br
485	es	*	Lista de todos os projetos	Lista de todos los Proyectos	2015-05-19 10:22:38.061618	pt-br
488	es	*	Lista de todos os atributos do projeto específico	Lista de todos los atributos del Proyecto específico	2015-05-19 10:22:38.075817	pt-br
491	es	*	id do projeto	ID del proyecto	2015-05-19 10:22:38.087475	pt-br
494	es	*	Lista de todos os objetivos	Lista de todos los objetivos	2015-05-19 10:22:38.0988	pt-br
497	es	*	Lista de todas as empresas	Lista de todas las Empresas	2015-05-19 10:22:38.11416	pt-br
500	es	*	voltar para endpoints	volver a los endpoints	2015-05-19 10:24:07.459628	pt-br
503	es	*	Lista de todas as empresas por metas de acordo com os orçamentos utilizados	Lista de todas las empresas por metas de acuerdo con los presupuestos utilizados	2015-05-19 10:30:04.91445	pt-br
506	es	*	Lista de todas as empresas por metas	Lista de todas las Empresas por metas	2015-05-19 10:30:04.926444	pt-br
509	es	*	Lista de todos os conselhos	Lista de todos los consejos	2015-05-19 10:30:04.938137	pt-br
512	es	*	Lista de todos os distritos	Lista de todos los Distritos	2015-05-19 10:30:04.950381	pt-br
515	es	*	Lista de todas as subprefeituras	Lista de todas las subprefecturas	2015-05-19 10:30:04.962622	pt-br
518	es	*	Exemplo de retorno	Ejemplo de retorno	2015-05-19 10:30:04.974326	pt-br
521	es	*	Selecione o Distrito	Selecione un Distrito	2015-05-19 11:03:10.599863	pt-br
524	es	*	Projetos neste Distrito	Proyectos en este Distrito	2015-05-19 11:03:22.222338	pt-br
527	es	*	Participe dos Eventos	Participar en Eventos	2015-05-19 11:03:22.239699	pt-br
530	es	*	Nome da campanha	Nombre de la Campaña	2015-05-19 11:03:22.253415	pt-br
533	es	*	Encontre seu distrito	Encontrar su distrito	2015-05-19 11:03:30.532965	pt-br
536	es	*	Conselhos Participativos	Consejos Participativos	2015-05-19 11:04:17.756487	pt-br
539	es	*	Siga o Conselho	Seguir el Consejo	2015-05-19 11:05:04.762165	pt-br
542	es	*	Conselho participativo	Consejo Participativo	2015-05-19 11:05:04.776262	pt-br
545	es	*	Total Recebido	Total Recibido	2015-05-19 11:06:11.259562	pt-br
548	es	*	Valor empenhado	Importe Comprometido	2015-05-19 11:06:11.272167	pt-br
551	es	*	Meta(s) Associada(s)	Meta(s) Associada(s)	2015-05-19 11:06:11.284895	pt-br
554	es	*	Efetuar download das tabelas	Descargar las tablas	2015-05-19 11:06:17.259042	pt-br
557	es	*	Acesso	Acceso	2015-05-19 11:16:23.031049	pt-br
560	es	*	Esqueceu a senha	Has olvidado tu contraseña	2015-05-19 11:16:23.044697	pt-br
641	es	*	CONVIDE UM NOVO CONSELHEIRO POR E-MAIL	Invitar a un nuevo consejero por mail	2015-05-19 14:33:44.173111	pt-br
566	es	*	Faça seu Cadastro	Registrarse	2015-05-19 11:16:23.066667	pt-br
569	es	*	Conselheiro? Clique aqui!	Si es consejero cliquee aquí!	2015-05-19 11:16:23.07847	pt-br
575	es	*	Notificações Recentes	Notificaciones Recientes	2015-05-19 11:47:53.48605	pt-br
578	es	*	Nenhuma notificação	No hay notificaciones	2015-05-19 11:47:53.502804	pt-br
581	es	*	Atividades recentes	Actividades recientes	2015-05-19 11:47:53.517595	pt-br
584	es	*	Cadastrar Campanhas	Crear Campañas	2015-05-19 11:47:58.214531	pt-br
587	es	*	Cadastrar Eventos	Crear Eventos	2015-05-19 11:47:58.226968	pt-br
590	es	*	CADASTRE UMA NOVA CAMPANHA	REGISTRAR UNA NUEVA CAMPAÑA	2015-05-19 11:47:58.238086	pt-br
593	es	*	Editar perfil	Editar perfil	2015-05-19 12:25:53.316065	pt-br
596	es	*	Campanha de dados móveis	Campaña de datos móviles	2015-05-19 12:25:53.329955	pt-br
599	es	*	Convidar	Invitar	2015-05-19 12:25:53.341378	pt-br
602	es	*	Membros do Conselho	Miembros del Consejo	2015-05-19 12:25:53.350752	pt-br
605	es	*	Seguindo	Siguiente	2015-05-19 12:25:53.362222	pt-br
608	es	*	Segurança	Seguridad	2015-05-19 12:25:53.375242	pt-br
611	es	*	Email	Email	2015-05-19 14:04:59.919707	pt-br
614	es	*	Data de cadastro	Fecha de registro	2015-05-19 14:04:59.931908	pt-br
617	es	*	FOTO DO PERFIL	FOTO DE PERFIL	2015-05-19 14:10:11.530985	pt-br
620	es	*	Faça upload de uma foto para usar no seu perfil	Sube una foto para usar en tu perfil	2015-05-19 14:10:11.544636	pt-br
623	es	*	Criar nova campanha móvel	Crear  nueva campaña móvil	2015-05-19 14:14:38.520752	pt-br
626	es	*	Sem descrição	Sin descripción	2015-05-19 14:14:38.533755	pt-br
629	es	*	Pausada	Detenido	2015-05-19 14:14:38.550435	pt-br
632	es	*	Clonar	Clonar	2015-05-19 14:14:54.827099	pt-br
635	es	*	Formulário	Formulario	2015-05-19 14:33:44.141885	pt-br
638	es	*	CADASTRE UM NOVO CONSELHEIRO	REGISTRAR UN NUEVO CONSEJERO	2015-05-19 14:33:44.155842	pt-br
824	es	*	NOME:	NOMBRE	2015-06-04 16:47:33.334582	pt-br
644	es	*	Limpar	Limpar	2015-05-19 14:35:12.493745	pt-br
647	es	*	Enviar	Enviar	2015-05-19 14:35:12.509029	pt-br
650	es	*	Parar de seguir	Dejar de seguir	2015-05-19 14:35:50.911328	pt-br
653	es	*	CEP ou Endereço	Dirección o Código Postal	2015-05-19 14:36:06.516771	pt-br
656	es	*	Campanha Móvel	Campaña Móvil	2015-05-19 14:36:06.528307	pt-br
659	es	*	Faça upload de uma imagem para ilustrar a campanha	Sube una imagen para ilustrar la campaña	2015-05-19 14:36:06.541275	pt-br
662	es	*	Cadastrar	Registro	2015-05-19 14:36:06.554399	pt-br
665	es	*	Selecione	Seleccione	2015-05-19 14:36:06.568869	pt-br
668	es	*	Faça upload de uma imagem para ilustrar o evento	Sube una imagen para ilustrar el evento	2015-05-19 14:36:06.579718	pt-br
671	es	*	CAMPANHAS CADASTRADAS	CAMPAÑAS REGISTRADAS	2015-05-19 14:36:06.595578	pt-br
674	es	*	Editar	Editar	2015-05-19 14:36:06.609238	pt-br
677	es	*	Remover	Remover	2015-05-19 14:36:06.620625	pt-br
680	es	*	EVENTOS CADASTRADOS	EVENTOS REGISTRADOS	2015-05-19 14:36:06.634804	pt-br
683	es	*	Início	Inicio	2015-05-19 14:53:41.568164	pt-br
686	es	*	Organizações	Organizaciones	2015-05-19 14:53:41.581793	pt-br
689	es	*	Gestões	Gestiones	2015-05-19 14:53:41.595366	pt-br
692	es	*	Aprovações de Notificações	Aprobación de Notificaciones	2015-05-19 14:53:41.609118	pt-br
695	es	*	Requisições de Conselheiros	Las solicitudes de administración	2015-05-19 14:53:41.622169	pt-br
698	es	*	Aprovações de Comentários	Comentarios	2015-05-19 14:53:41.635531	pt-br
701	es	*	Fale Conosco	Contáctenos	2015-05-19 14:53:41.648415	pt-br
704	es	*	Usuários	Usuarios	2015-05-19 14:53:41.664654	pt-br
707	es	*	Adicionar nova organização	Agregar nueva organización	2015-05-19 14:53:45.888954	pt-br
710	es	*	Ações	Acciones	2015-05-19 14:53:45.90275	pt-br
713	es	*	Excluir	Eliminar	2015-05-19 14:53:45.915106	pt-br
716	es	*	Orçamento Executado	Presupuesto Ejecutado	2015-05-20 18:31:15.424617	pt-br
719	es	*	Porcentagem Concluída	Porcentaje alcanzado	2015-05-20 18:31:15.438929	pt-br
722	es	*	Descrição Técnica	Descripción Técnica	2015-05-20 18:31:26.362681	pt-br
725	es	*	Objetivo de entrega	Objetivo de entrega	2015-05-20 18:31:26.38094	pt-br
728	es	*	E-mail:	E-mail:	2015-05-20 19:48:28.197674	pt-br
734	es	*	Eventos	Eventos	2015-05-29 11:30:00.195552	pt-br
737	es	*	Nome:	Nombre:	2015-05-29 11:30:00.210075	pt-br
740	es	*	Descrição:	Descripción:	2015-05-29 11:30:00.222983	pt-br
743	es	*	Objetivo:	Objetivo:	2015-05-29 11:30:00.233564	pt-br
746	es	*	Texto livre:	Texto libre:	2015-05-29 11:30:00.24372	pt-br
749	es	*	Data Começo:	Fecha de inicio	2015-05-29 11:30:00.256366	pt-br
752	es	*	Data Final:	Fecha de Finalización:	2015-05-29 11:30:00.266566	pt-br
755	es	*	Data:	Fecha:	2015-05-29 11:30:00.278834	pt-br
758	es	*	Faça upload de um arquivo que contenha os dados da meta	Subir un archivo que contiene los datos de destino	2015-05-29 11:32:10.243773	pt-br
761	es	*	Nenhum orçamento encontrado	No hay comentarios	2015-05-29 15:37:59.434569	pt-br
764	es	*	Faça upload de um arquivo que contenha os dados do projeto	Subir un archivo que contiene los datos del proyecto	2015-05-29 17:47:25.290297	pt-br
767	es	*	Faça upload de um arquivo que contenha os dados do distrito	Subir un archivo que contiene los datos del Distrito	2015-06-01 13:54:42.667095	pt-br
773	es	*	Encontre a campanha	Encuentra la campaña	2015-06-03 12:07:21.607703	pt-br
776	es	*	Filtrar Campanha	Filtrar Campaña	2015-06-03 12:07:21.726305	pt-br
779	es	*	Participe das campanhas	Participe de la Campaña	2015-06-03 12:07:21.81169	pt-br
782	es	*	Nenhum valor encontrado	Ningún valor encontrado	2015-06-03 12:07:51.782517	pt-br
785	es	*	PROCURAR EMPRESAS	BUSCAR EMPRESAS	2015-06-03 14:50:08.199692	pt-br
788	es	*	Informe o Nome	Ingrese su Nombre	2015-06-03 14:50:08.276255	pt-br
791	es	*	FILTRAR EMPRESAS POR	FILTRAR EMPRESAS POR	2015-06-03 14:50:08.346434	pt-br
794	es	*	Organizações Encontradas	Organizaciones Encontradas	2015-06-03 14:50:08.465984	pt-br
797	es	*	*Nome:	*Nombre:	2015-06-04 08:56:01.36338	pt-br
800	es	*	*E-mail (será seu acesso ao sistema):	*E-mail (será su acceso al sistema):	2015-06-04 08:56:01.480712	pt-br
803	es	*	*Criar uma senha:	? *Crear una contraseña:	2015-06-04 08:56:01.565451	pt-br
806	es	*	*Confirme a senha:	Confirme la contraseña:	2015-06-04 08:56:01.633749	pt-br
827	es	*	E-MAIL:	E-MAIL:	2015-06-04 16:47:33.635705	pt-br
830	es	*	Nenhum progresso até o momento	No hay progreso hasta el momento	2015-06-04 17:03:51.874431	pt-br
836	es	*	NENHUM PROJETO NA REGIÃO	NO HAY PROYECTOS EN LA REGIÓN	2015-06-05 16:17:18.393522	pt-br
839	es	*	NENHUMA REGIÃO ENCONTRADA	REGIÓN NO ENCONTRADA	2015-06-07 00:39:28.558127	pt-br
842	es	*	Valor dedicado	Importe destinado	2015-06-08 11:36:40.3547	pt-br
845	es	*	Código de empenho	Código de compromiso	2015-06-08 11:36:40.52486	pt-br
848	es	*	Participe das Campanhas	Unirte a la Campaña	2015-06-08 13:57:18.702822	pt-br
851	es	*	Campanha	Campaña	2015-06-08 19:59:22.698111	pt-br
854	es	*	NENHUM EVENTO ENCONTRADO	NO SE ENCONTRARON EVENTOS	2015-06-08 19:59:22.766961	pt-br
857	es	*	O projeto	El proyecto	2015-06-10 16:19:01.936364	pt-br
860	es	*	foi atualizado	se ha actualizado	2015-06-10 16:19:02.09121	pt-br
863	es	*	Avaliação dos conselheiros sobre o andamento do projeto	Valoración de los consejeros sobre el avance del proyecto	2015-06-10 16:20:09.200283	pt-br
866	es	*	Qual sua avaliação a respeito do projeto? Selecione uma das opções abaixo	¿Cuál es su opinión sobre el proyecto? Seleccione una opción a continuación	2015-06-10 16:20:09.269362	pt-br
872	es	*	Em progresso	En curso	2015-06-10 16:20:09.407905	pt-br
875	es	*	Completo	Completo	2015-06-10 16:20:09.479839	pt-br
878	es	*	Senha Atual	Contraseña actual	2015-06-22 10:31:34.592223	pt-br
881	es	*	Nova Senha	Nueva contraseña	2015-06-22 10:31:34.734465	pt-br
884	es	*	Confirme Nova Senha	Confirmar nueva contraseña	2015-06-22 10:31:34.839728	pt-br
887	es	*	Valor inválido	Valor incorrecto	2015-06-22 10:32:02.146385	pt-br
890	es	*	Confirmação de senha	Confirmación de contraseña	2015-06-22 10:43:21.371536	pt-br
893	es	*	Nenhuma campanha cadastrada	No hay campaña registrada	2015-06-22 10:49:38.509769	pt-br
896	es	*	Nenhum evento cadastrado	No hay evento registrado	2015-06-22 10:49:38.600853	pt-br
899	es	*	Este campo não pode ser vazio	Este campo debe ser completado	2015-06-29 08:10:28.512477	pt-br
902	es	*	Modelo de arquivo para preenchimento	Plantilla de archivos para llenar	2015-06-30 16:33:48.40816	pt-br
908	es	*	METAS	METAS	2015-06-30 16:33:48.580341	pt-br
911	es	*	REGIÕES	REGIONES	2015-06-30 16:33:48.675388	pt-br
914	es	*	Importar Arquivo	Importar Archivo	2015-06-30 16:33:48.744977	pt-br
\.


--
-- Name: lexicon_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('lexicon_id_seq', 1038, true);


--
-- Name: lexicon_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY lexicon
    ADD CONSTRAINT lexicon_pkey PRIMARY KEY (id);


--
-- Name: ix_lexicon_words; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX ix_lexicon_words ON lexicon USING btree (lang, md5(lex_key));


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

